package ma.gdd.syncro;

import java.nio.file.*;
import java.util.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.batch.item.ExecutionContext;
import static org.assertj.core.api.Assertions.*;

class CsvReadersTest {
	@TempDir
	Path folder;
	private final TableSpec spec = new TableSpec("Amplitude", "bank", "BKAGE", "Syncro_am_BKAGE",
			List.of("AGE", "LIB"));

	private Path file(String text) throws Exception {
		Path f = folder.resolve("test.csv");
		Files.writeString(f, text);
		return f;
	}

	@Test
	void acceptsQuotedSeparatorsBomAndBlankValues() throws Exception {
		var reader = CsvReaders.create(spec,
				file("\uFEFFsyncro_reference;AGE;LIB\nREF1;00001;\"Agence; Démo\"\nREF2;00002;\n"), ";");
		reader.open(new ExecutionContext());
		try {
			assertThat(reader.read()).isEqualTo(new SyncroRow("REF1", List.of("00001", "Agence; Démo")));
			var row = reader.read();
			assertThat(row.values()).containsExactly("00002", null);
			assertThat(reader.read()).isNull();
		} finally {
			reader.close();
		}
	}

	@Test
	void rejectsIncorrectHeader() throws Exception {
		var reader = CsvReaders.create(spec, file("syncro_reference;LIB;AGE\nR;X;Y\n"), ";");
		assertThatThrownBy(() -> reader.open(new ExecutionContext())).isInstanceOf(Exception.class);
		reader.close();
	}

	@Test
	void rejectsMissingReferenceAndIncorrectColumnCount() throws Exception {
		var reader = CsvReaders.create(spec, file("syncro_reference;AGE;LIB\n;00001;Demo\n"), ";");
		reader.open(new ExecutionContext());
		try {
			assertThatThrownBy(reader::read).isInstanceOf(Exception.class);
		} finally {
			reader.close();
		}
		var wrong = CsvReaders.create(spec, file("syncro_reference;AGE;LIB\nREF1;00001;Demo;EXTRA\n"), ";");
		wrong.open(new ExecutionContext());
		try {
			assertThatThrownBy(wrong::read).isInstanceOf(Exception.class);
		} finally {
			wrong.close();
		}
	}

	@Test
	void resumesAtLastCommittedItem() throws Exception {
		Path file = file("syncro_reference;AGE;LIB\nR1;1;A\nR2;2;B\n");
		var context = new ExecutionContext();
		var first = CsvReaders.create(spec, file, ";");
		first.open(context);
		first.read();
		first.update(context);
		first.close();
		var restart = CsvReaders.create(spec, file, ";");
		restart.open(context);
		try {
			assertThat(restart.read().reference()).isEqualTo("R2");
			assertThat(restart.read()).isNull();
		} finally {
			restart.close();
		}
	}

	@Test
	void allTwentyTwoSampleFilesMatchCatalog() throws Exception {
		var catalog = new TableCatalog(new ObjectMapper());
		int count = 0;
		for (var table : catalog.all()) {
			Path sample = Path.of("data/examples/" + table.targetTable() + "__20261012.csv");
			var reader = CsvReaders.create(table, sample, ";");
			reader.open(new ExecutionContext());
			try {
				assertThat(reader.read().values()).hasSize(table.fields().size());
				assertThat(reader.read()).isNull();
			} finally {
				reader.close();
			}
			count++;
		}
		assertThat(count).isEqualTo(22);
		assertThat(catalog.all().stream().mapToInt(t -> t.fields().size()).sum()).isEqualTo(656);
	}

	@Test
	void quotedNewlineAndEscapedQuotesAreSupported() throws Exception {
		var reader = CsvReaders.create(spec, file("syncro_reference;AGE;LIB\nR1;1;\"Agence\n\"\"Démo\"\"\"\n"), ";");
		reader.open(new ExecutionContext());
		try {
			assertThat(reader.read().values().get(1)).contains("Agence").contains("\"Démo\"");
		} finally {
			reader.close();
		}
	}
}
