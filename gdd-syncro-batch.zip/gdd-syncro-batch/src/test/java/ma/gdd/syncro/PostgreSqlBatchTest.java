package ma.gdd.syncro;

import java.nio.file.*;
import java.util.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.*;
import static org.assertj.core.api.Assertions.*;

@SpringBootTest
@Testcontainers(disabledWithoutDocker = true)
class PostgreSqlBatchTest {
	@Container
	static final PostgreSQLContainer<?> POSTGRES = new PostgreSQLContainer<>("postgres:17-alpine");
	static final Path INPUT = createDir();
	static final Path ARCHIVE = createDir();

	private static Path createDir() {
		try {
			return Files.createTempDirectory("gdd-it-");
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	@DynamicPropertySource
	static void properties(DynamicPropertyRegistry r) {
		r.add("spring.datasource.url", POSTGRES::getJdbcUrl);
		r.add("spring.datasource.username", POSTGRES::getUsername);
		r.add("spring.datasource.password", POSTGRES::getPassword);
		r.add("gdd.input-directory", INPUT::toString);
		r.add("gdd.archive-directory", ARCHIVE::toString);
		r.add("gdd.cron", () -> "-");
		r.add("gdd.chunk-size", () -> 1);
	}

	@Autowired
	DirectoryImportService importer;
	@Autowired
	JdbcTemplate jdbc;

	@Test
	void endToEndInsertUpdateDuplicateFailureAndReplay() throws Exception {
		Path file = INPUT.resolve("Syncro_am_BKAGE.csv");
		Files.writeString(file, "syncro_reference;AGE;LIB\nTEST_1;00001;Agence initiale\n");
		importer.scan();
		assertThat(file).doesNotExist();
		Map<String, Object> first = jdbc
				.queryForMap("SELECT * FROM public.\"Syncro_am_BKAGE\" WHERE syncro_reference='TEST_1'");
		assertThat(first.get("LIB")).isEqualTo("Agence initiale");
		Object created = first.get("syncro_date_creation");
		Files.writeString(file, "syncro_reference;AGE;LIB\nTEST_1;00001;Agence modifiée\n");
		importer.scan();
		Map<String, Object> updated = jdbc
				.queryForMap("SELECT * FROM public.\"Syncro_am_BKAGE\" WHERE syncro_reference='TEST_1'");
		assertThat(updated.get("LIB")).isEqualTo("Agence modifiée");
		assertThat(updated.get("syncro_date_creation")).isEqualTo(created);
		assertThat(updated.get("syncro_date_synchronisation")).isNotEqualTo(first.get("syncro_date_synchronisation"));
		// Deux mêmes références dans le fichier : staging échoue et la cible reste
		// intacte.
		Files.writeString(file, "syncro_reference;AGE;LIB\nTEST_1;00001;INVALID\nTEST_1;00001;DUPLICATE\n");
		importer.scan();
		assertThat(file).exists();
		assertThat(jdbc.queryForObject("SELECT \"LIB\" FROM public.\"Syncro_am_BKAGE\" WHERE syncro_reference='TEST_1'",
				String.class)).isEqualTo("Agence modifiée");
		Files.delete(file);
		// Redépôt du même contenu déjà réussi : aucune nouvelle synchronisation.
		Files.writeString(file, "syncro_reference;AGE;LIB\nTEST_1;00001;Agence modifiée\n");
		importer.scan();
		assertThat(file).doesNotExist();
		assertThat(jdbc.queryForObject(
				"SELECT syncro_date_synchronisation FROM public.\"Syncro_am_BKAGE\" WHERE syncro_reference='TEST_1'",
				java.sql.Timestamp.class)).isEqualTo(updated.get("syncro_date_synchronisation"));
		// En-tête seul : pas de publication ni d'archivage.
		Files.writeString(file, "syncro_reference;AGE;LIB\n");
		importer.scan();
		assertThat(file).exists();
		Files.delete(file);
	}
}
