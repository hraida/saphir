package ma.gdd.syncro;

import java.nio.file.*;
import java.util.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.assertj.core.api.Assertions.*;

class CatalogAndArchiveTest {
	@TempDir
	Path dir;

	@Test
	void identifiersAreWhitelistedAndNamesUnambiguous() throws Exception {
		var c = new TableCatalog(new ObjectMapper());
		assertThat(c.fromFileName("Syncro_am_BKAGE__20261012.csv")).isPresent();
		assertThat(c.fromFileName("Syncro_Ls_PAM.csv")).isPresent();
		assertThat(c.fromFileName("Syncro_am_BKAGE_EXTRA.csv")).isEmpty();
		assertThat(c.fromFileName("injection.csv")).isEmpty();
		assertThatThrownBy(() -> c.require("other_table")).isInstanceOf(IllegalArgumentException.class);
		assertThatThrownBy(() -> TableSpec.quote("BKAGE; DROP TABLE x")).isInstanceOf(IllegalArgumentException.class);
	}

	@Test
	void publicationSqlUpdatesBusinessFieldsButPreservesCreationDate() throws Exception {
		var s = new TableCatalog(new ObjectMapper()).require("Syncro_am_BKAGE");
		assertThat(s.publishSql()).contains("ON CONFLICT (syncro_reference) DO UPDATE")
				.contains("\"AGE\" = EXCLUDED.\"AGE\"").contains("WHERE batch_key = ?")
				.doesNotContain("syncro_date_creation =").doesNotContain("DELETE");
	}

	@Test
	void archiveIsIdempotentAndRejectsChangedFiles() throws Exception {
		var props = new SyncroProperties(dir.resolve("in"), dir.resolve("archive"), ";", "-", "Africa/Casablanca", 10,
				false, 7246012);
		var archiver = new FileArchiver(props);
		Files.createDirectories(props.inputDirectory());
		Path file = props.inputDirectory().resolve("a.csv");
		Files.writeString(file, "ABC");
		String hash = Fingerprints.sha256(file);
		archiver.archive(file, hash, "Syncro_am_BKAGE");
		assertThat(file).doesNotExist();
		archiver.archive(file, hash, "Syncro_am_BKAGE");
		Files.writeString(file, "CHANGED");
		assertThatThrownBy(() -> archiver.archive(file, hash, "Syncro_am_BKAGE"))
				.isInstanceOf(java.io.IOException.class);
		assertThat(file).exists();
	}
}
