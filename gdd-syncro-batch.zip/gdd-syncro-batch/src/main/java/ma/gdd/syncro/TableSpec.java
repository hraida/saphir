package ma.gdd.syncro;

import java.util.*;
import java.util.stream.Collectors;

public record TableSpec(String source, String schemaSource, String sourceTable, String targetTable,
		List<String> fields) {
	public TableSpec {
		fields = List.copyOf(fields);
		quote(targetTable);
		fields.forEach(TableSpec::quote);
		if (fields.isEmpty() || new HashSet<>(fields).size() != fields.size())
			throw new IllegalArgumentException("Champs invalides");
	}

	public static String quote(String name) {
		if (name == null || !name.matches("[A-Za-z_][A-Za-z0-9_]*"))
			throw new IllegalArgumentException("Identifiant SQL invalide");
		return "\"" + name + "\"";
	}

	public List<String> csvColumns() {
		var result = new ArrayList<String>();
		result.add("syncro_reference");
		result.addAll(fields);
		return List.copyOf(result);
	}

	public String targetSql() {
		return "public." + quote(targetTable);
	}

	public String stageSql() {
		return "gdd_stage." + quote(targetTable);
	}

	public String stageInsertSql() {
		var columns = new ArrayList<String>();
		columns.add("batch_key");
		columns.addAll(csvColumns());
		return "INSERT INTO " + stageSql() + " ("
				+ columns.stream().map(TableSpec::quote).collect(Collectors.joining(", ")) + ") VALUES ("
				+ Collections.nCopies(columns.size(), "?").stream().collect(Collectors.joining(", ")) + ")";
	}

	public String publishSql() {
		String cols = csvColumns().stream().map(TableSpec::quote).collect(Collectors.joining(", "));
		String assignments = fields.stream().map(f -> quote(f) + " = EXCLUDED." + quote(f))
				.collect(Collectors.joining(", "));
		return "INSERT INTO " + targetSql() + " (" + cols + ", syncro_date_synchronisation) SELECT " + cols
				+ ", statement_timestamp() FROM " + stageSql() + " WHERE batch_key = ? "
				+ "ON CONFLICT (syncro_reference) DO UPDATE SET " + assignments
				+ ", syncro_date_synchronisation = EXCLUDED.syncro_date_synchronisation";
	}
}
