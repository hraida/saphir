package ma.gdd.syncro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@EnableConfigurationProperties(SyncroProperties.class)
public class GddSyncroApplication {
	public static void main(String[] args) {
		SpringApplication.run(GddSyncroApplication.class, args);
	}
}
