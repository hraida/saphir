package ma.gdd.syncro;

import java.util.List;

public record SyncroRow(String reference, List<String> values) {
}
