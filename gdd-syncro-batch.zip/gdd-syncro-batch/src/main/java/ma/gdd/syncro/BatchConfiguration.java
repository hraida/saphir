package ma.gdd.syncro;

import java.nio.file.*;
import java.util.*;
import javax.sql.DataSource;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
public class BatchConfiguration {
	@Bean
	@StepScope
	public FlatFileItemReader<SyncroRow> csvReader(TableCatalog catalog, SyncroProperties props,
			@Value("#{jobParameters['table']}") String table, @Value("#{jobParameters['file']}") String file) {
		return CsvReaders.create(catalog.require(table), Path.of(file), props.delimiter());
	}

	@Bean
	@StepScope
	public JdbcBatchItemWriter<SyncroRow> stageWriter(DataSource dataSource, TableCatalog catalog,
			@Value("#{jobParameters['table']}") String table, @Value("#{jobParameters['batchKey']}") String key) {
		var spec = catalog.require(table);
		return new JdbcBatchItemWriterBuilder<SyncroRow>().dataSource(dataSource).sql(spec.stageInsertSql())
				.itemPreparedStatementSetter((row, ps) -> {
					ps.setString(1, key);
					ps.setString(2, row.reference());
					for (int i = 0; i < row.values().size(); i++)
						ps.setString(i + 3, row.values().get(i));
				}).assertUpdates(true).build();
	}

	@Bean
	public Step loadStaging(JobRepository repository, PlatformTransactionManager tx,
			FlatFileItemReader<SyncroRow> csvReader, JdbcBatchItemWriter<SyncroRow> stageWriter,
			SyncroProperties props) {
		return new StepBuilder("loadStaging", repository).<SyncroRow, SyncroRow>chunk(props.chunkSize(), tx)
				.reader(csvReader).writer(stageWriter).build();
	}

	@Bean
	public Step publishTable(JobRepository repository, PlatformTransactionManager tx, JdbcTemplate jdbc,
			TableCatalog catalog) {
		return new StepBuilder("publishTable", repository).tasklet((contribution, context) -> {
			var parameters = contribution.getStepExecution().getJobParameters();
			var spec = catalog.require(parameters.getString("table"));
			String key = parameters.getString("batchKey");
			Path file = Path.of(parameters.getString("file"));
			if (!Fingerprints.sha256(file).equals(parameters.getString("hash")))
				throw new IllegalStateException("Fichier modifié durant le chargement");
			Long count = jdbc.queryForObject("SELECT count(*) FROM " + spec.stageSql() + " WHERE batch_key=?",
					Long.class, key);
			if (count == null || count == 0)
				throw new IllegalStateException("Fichier sans données : publication refusée");
			int published = jdbc.update(spec.publishSql(), key);
			contribution.getStepExecution().getExecutionContext().putLong("publishedRows", published);
			jdbc.update("DELETE FROM " + spec.stageSql() + " WHERE batch_key=?", key);
			return RepeatStatus.FINISHED;
		}, tx).build();
	}

	@Bean
	public Step archiveFile(JobRepository repository, PlatformTransactionManager tx, FileArchiver archiver) {
		return new StepBuilder("archiveFile", repository).tasklet((contribution, context) -> {
			var p = contribution.getStepExecution().getJobParameters();
			archiver.archive(Path.of(p.getString("file")), p.getString("hash"), p.getString("table"));
			return RepeatStatus.FINISHED;
		}, tx).build();
	}

	@Bean
	public Job syncroFileJob(JobRepository repository, Step loadStaging, Step publishTable, Step archiveFile) {
		return new JobBuilder("syncroFileJob", repository).start(loadStaging).next(publishTable).next(archiveFile)
				.build();
	}
}
