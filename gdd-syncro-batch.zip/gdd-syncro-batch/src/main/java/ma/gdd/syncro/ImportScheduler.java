package ma.gdd.syncro;

import org.slf4j.*;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ImportScheduler {
	private static final Logger log = LoggerFactory.getLogger(ImportScheduler.class);
	private final DirectoryImportService importer;
	private final SyncroProperties props;

	public ImportScheduler(DirectoryImportService importer, SyncroProperties props) {
		this.importer = importer;
		this.props = props;
	}

	@Scheduled(cron = "${gdd.cron}", zone = "${gdd.zone}")
	public void run() {
		try {
			importer.scan();
		} catch (Exception e) {
			log.error("Échec du déclenchement batch : {}", e.getClass().getSimpleName());
		}
	}

	@EventListener(ApplicationReadyEvent.class)
	public void startup() {
		if (props.runOnStartup())
			run();
	}
}
