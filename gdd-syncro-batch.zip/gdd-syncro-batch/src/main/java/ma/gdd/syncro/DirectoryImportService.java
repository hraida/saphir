package ma.gdd.syncro;

import java.nio.file.*;
import java.sql.*;
import java.util.*;
import javax.sql.DataSource;
import org.slf4j.*;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.stereotype.Service;

@Service
public class DirectoryImportService {
	private static final Logger log = LoggerFactory.getLogger(DirectoryImportService.class);
	private final DataSource dataSource;
	private final SyncroProperties props;
	private final TableCatalog catalog;
	private final JobLauncher launcher;
	private final Job job;
	private final FileArchiver archiver;

	public DirectoryImportService(DataSource ds, SyncroProperties p, TableCatalog c, JobLauncher l, Job syncroFileJob,
			FileArchiver a) {
		dataSource = ds;
		props = p;
		catalog = c;
		launcher = l;
		job = syncroFileJob;
		archiver = a;
	}

	public void scan() throws Exception {
		Path input = props.inputDirectory().toAbsolutePath().normalize();
		Files.createDirectories(input);
		try (var connection = dataSource.getConnection()) {
			if (!lock(connection)) {
				log.info("Import déjà en cours ; déclenchement ignoré");
				return;
			}
			try {
				List<Path> files;
				try (var stream = Files.list(input)) {
					files = stream.filter(p -> Files.isRegularFile(p, LinkOption.NOFOLLOW_LINKS))
							.filter(p -> p.getFileName().toString().endsWith(".csv")).sorted().toList();
				}
				for (Path file : files) {
					var spec = catalog.fromFileName(file.getFileName().toString());
					if (spec.isEmpty()) {
						log.warn("Fichier ignoré : nom non répertorié {}", file.getFileName());
						continue;
					}
					try {
						launch(file, spec.get());
					} catch (Exception e) {
						log.error("Import en échec pour {} : {}. Fichier conservé pour reprise.", file.getFileName(),
								e.getClass().getSimpleName());
					}
				}
			} finally {
				try (var st = connection.prepareStatement("SELECT pg_advisory_unlock(?)")) {
					st.setLong(1, props.advisoryLockKey());
					st.execute();
				}
			}
		}
	}

	private boolean lock(Connection c) throws SQLException {
		try (var statement = c.prepareStatement("SELECT pg_try_advisory_lock(?)")) {
			statement.setLong(1, props.advisoryLockKey());
			try (var result = statement.executeQuery()) {
				result.next();
				return result.getBoolean(1);
			}
		}
	}

	private void launch(Path file, TableSpec spec) throws Exception {
		String hash = Fingerprints.sha256(file);
		String batchKey = spec.targetTable() + ":" + hash;
		var parameters = new JobParametersBuilder().addString("table", spec.targetTable()).addString("hash", hash)
				.addString("batchKey", batchKey).addString("file", file.toString(), false).toJobParameters();
		try {
			var execution = launcher.run(job, parameters);
			log.info("Import table={} execution={} statut={}", spec.targetTable(), execution.getId(),
					execution.getStatus());
			if (execution.getStatus() != BatchStatus.COMPLETED)
				log.warn(
						"Échec : {}. Consulter BATCH_STEP_EXECUTION et corriger le fichier ou reprendre le même contenu.",
						file.getFileName());
		} catch (JobInstanceAlreadyCompleteException e) {
			// Même contenu déjà importé : pas d'écriture supplémentaire dans la cible.
			archiver.archive(file, hash, spec.targetTable());
			log.info("Contenu déjà importé et archivé : {}", file.getFileName());
		}
	}
}
