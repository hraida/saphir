package ma.gdd.syncro;

import java.nio.file.*;
import java.io.IOException;
import org.springframework.stereotype.Component;

@Component
public class FileArchiver {
	private final SyncroProperties properties;

	public FileArchiver(SyncroProperties properties) {
		this.properties = properties;
	}

	public void archive(Path file, String hash, String table) throws IOException {
		Path folder = properties.archiveDirectory().toAbsolutePath().normalize().resolve(table);
		Files.createDirectories(folder);
		Path destination = folder.resolve(hash + ".csv");
		if (Files.exists(destination)) {
			if (!Fingerprints.sha256(destination).equals(hash))
				throw new IOException("Collision ou archive altérée");
			if (Files.exists(file)) {
				if (!Fingerprints.sha256(file).equals(hash))
					throw new IOException("Fichier source modifié");
				Files.delete(file);
			}
			return;
		}
		if (!Files.exists(file) || !Fingerprints.sha256(file).equals(hash))
			throw new IOException("Fichier absent ou modifié avant archivage");
		// Copie temporaire : fonctionne aussi si entrée et archive sont sur deux
		// volumes.
		Path temporary = folder.resolve(hash + ".part");
		Files.copy(file, temporary, StandardCopyOption.REPLACE_EXISTING);
		if (!Fingerprints.sha256(temporary).equals(hash))
			throw new IOException("Copie archive invalide");
		try {
			Files.move(temporary, destination, StandardCopyOption.ATOMIC_MOVE);
		} catch (AtomicMoveNotSupportedException e) {
			Files.move(temporary, destination);
		}
		Files.delete(file);
	}
}
