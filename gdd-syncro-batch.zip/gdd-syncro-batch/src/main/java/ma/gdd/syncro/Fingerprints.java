package ma.gdd.syncro;

import java.nio.file.*;
import java.security.*;
import java.util.HexFormat;
import java.io.IOException;

public final class Fingerprints {
	private Fingerprints() {
	}

	public static String sha256(Path file) throws IOException {
		try {
			var digest = MessageDigest.getInstance("SHA-256");
			try (var in = Files.newInputStream(file)) {
				byte[] b = new byte[65536];
				int n;
				while ((n = in.read(b)) != -1)
					digest.update(b, 0, n);
			}
			return HexFormat.of().formatHex(digest.digest());
		} catch (NoSuchAlgorithmException e) {
			throw new IllegalStateException(e);
		}
	}
}
