package ma.gdd.syncro;

import java.util.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * Exemple à intégrer dans l'application GDD pour remplacer les accès directs
 * LS/Amplitude.
 */
@Repository
public class SynchronizedDataReader {
	private final JdbcTemplate jdbc;
	private final TableCatalog catalog;

	public SynchronizedDataReader(JdbcTemplate jdbc, TableCatalog catalog) {
		this.jdbc = jdbc;
		this.catalog = catalog;
	}

	public Optional<Map<String, Object>> findByReference(String table, String reference) {
		var spec = catalog.require(table);
		var rows = jdbc.queryForList("SELECT * FROM " + spec.targetSql() + " WHERE syncro_reference=?", reference);
		return rows.stream().findFirst();
	}

	public List<Map<String, Object>> findByBusinessField(String table, String field, String value, int limit) {
		var spec = catalog.require(table);
		if (!spec.fields().contains(field))
			throw new IllegalArgumentException("Champ non autorisé");
		if (limit < 1 || limit > 1000)
			throw new IllegalArgumentException("Limite entre 1 et 1000");
		return jdbc.queryForList("SELECT * FROM " + spec.targetSql() + " WHERE " + TableSpec.quote(field)
				+ "=? ORDER BY syncro_reference LIMIT ?", value, limit);
	}
}
