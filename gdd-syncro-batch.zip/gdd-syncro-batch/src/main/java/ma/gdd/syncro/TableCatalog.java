package ma.gdd.syncro;

import java.io.IOException;
import java.util.*;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

@Component
public class TableCatalog {
	private final Map<String, TableSpec> tables;

	public TableCatalog(ObjectMapper mapper) throws IOException {
		try (var in = new ClassPathResource("table-catalog.json").getInputStream()) {
			List<TableSpec> specs = mapper.readValue(in, new TypeReference<>() {
			});
			var result = new LinkedHashMap<String, TableSpec>();
			for (var spec : specs)
				if (result.put(spec.targetTable(), spec) != null)
					throw new IllegalArgumentException("Table dupliquée");
			tables = Collections.unmodifiableMap(result);
		}
	}

	public TableSpec require(String target) {
		var spec = tables.get(target);
		if (spec == null)
			throw new IllegalArgumentException("Table non autorisée : " + target);
		return spec;
	}

	public Collection<TableSpec> all() {
		return tables.values();
	}

	public Optional<TableSpec> fromFileName(String filename) {
		return tables.values().stream().filter(t -> filename.equals(t.targetTable() + ".csv")
				|| (filename.startsWith(t.targetTable() + "__") && filename.endsWith(".csv"))).findFirst();
	}
}
