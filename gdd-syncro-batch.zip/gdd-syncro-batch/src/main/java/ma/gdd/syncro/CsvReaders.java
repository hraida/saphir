package ma.gdd.syncro;

import java.nio.file.Path;
import java.util.*;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.separator.DefaultRecordSeparatorPolicy;
import org.springframework.core.io.FileSystemResource;

public final class CsvReaders {
	private CsvReaders() {
	}

	public static FlatFileItemReader<SyncroRow> create(TableSpec spec, Path file, String delimiter) {
		var tokenizer = new DelimitedLineTokenizer(delimiter);
		tokenizer.setNames(spec.csvColumns().toArray(String[]::new));
		tokenizer.setStrict(true);
		tokenizer.setQuoteCharacter('"');
		var reader = new FlatFileItemReader<SyncroRow>();
		reader.setName("syncroCsvReader");
		reader.setResource(new FileSystemResource(file));
		reader.setEncoding("UTF-8");
		reader.setStrict(true);
		reader.setSaveState(true);
		reader.setComments(new String[0]);
		reader.setLinesToSkip(1);
		reader.setRecordSeparatorPolicy(new DefaultRecordSeparatorPolicy());
		reader.setSkippedLinesCallback(line -> {
			String header = line.startsWith("\uFEFF") ? line.substring(1) : line;
			if (!Arrays.asList(tokenizer.tokenize(header).getValues()).equals(spec.csvColumns()))
				throw new IllegalArgumentException("En-tête CSV incorrect pour " + spec.targetTable());
		});
		reader.setLineMapper((line, number) -> {
			String[] values = tokenizer.tokenize(line).getValues();
			String reference = values[0].trim();
			if (reference.isEmpty() || reference.length() > 512)
				throw new IllegalArgumentException("Référence absente ou trop longue à la ligne " + number);
			var fields = new ArrayList<String>();
			for (int i = 1; i < values.length; i++)
				fields.add(values[i].isEmpty() ? null : values[i]);
			return new SyncroRow(reference, Collections.unmodifiableList(fields));
		});
		return reader;
	}
}
