package ma.gdd.syncro;

import java.nio.file.Path;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "gdd")
public record SyncroProperties(Path inputDirectory, Path archiveDirectory, String delimiter, String cron, String zone,
		int chunkSize, boolean runOnStartup, long advisoryLockKey) {
	public SyncroProperties {
		if (inputDirectory == null || archiveDirectory == null)
			throw new IllegalArgumentException("Répertoires obligatoires");
		if (inputDirectory.toAbsolutePath().normalize().equals(archiveDirectory.toAbsolutePath().normalize()))
			throw new IllegalArgumentException("Entrée et archive doivent être distinctes");
		if (delimiter == null || delimiter.length() != 1 || delimiter.equals("\"") || delimiter.equals("\n"))
			throw new IllegalArgumentException("Séparateur CSV invalide");
		if (chunkSize < 1 || chunkSize > 10000)
			throw new IllegalArgumentException("Chunk entre 1 et 10000");
		java.time.ZoneId.of(zone);
	}
}
