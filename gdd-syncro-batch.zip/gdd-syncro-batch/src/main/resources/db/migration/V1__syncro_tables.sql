-- GDD | Référence : TablesChamps 1.7 | PostgreSQL
-- 22 tables, 656 champs métier et 4 champs techniques par table.
-- Les types métier sont provisoirement TEXT : le fichier ne donne aucun type.
-- Respect des noms et de leur casse : utiliser les identifiants entre guillemets.
-- syncro_reference : clé stable fournie par le batch à partir de la clé source.
-- Ne pas générer une nouvelle référence à chaque import ; elle sert à l'UPSERT.
-- syncro_date_creation : première insertion locale, à préserver lors des mises à jour.
-- syncro_date_update : dernière modification locale, alimentée par le déclencheur.
-- syncro_date_synchronisation : dernier import, à actualiser dans chaque UPSERT,
-- même si les données métier ne changent pas. Horodatages TIMESTAMPTZ.
-- Les champs techniques sont préfixés pour éviter un conflit avec DATE_CREATION
-- déjà présent dans la table métier ENGAGEMENT.
-- Les clés métier et leurs éventuelles compositions restent à confirmer.
-- Le script crée la structure et la fonction de suivi ; il ne planifie pas le batch.

CREATE OR REPLACE FUNCTION public.gdd_syncro_maj_date_update()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    NEW.syncro_date_creation := OLD.syncro_date_creation;
    NEW.syncro_date_update := clock_timestamp();
    RETURN NEW;
END;
$$;

-- Amplitude | Source : Informix.bank.BKAGE | 2 champs métier
CREATE TABLE public."Syncro_am_BKAGE" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "AGE" TEXT,
    "LIB" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_am_BKAGE"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- Amplitude | Source : Informix.bank.BKAUTC | 55 champs métier
CREATE TABLE public."Syncro_am_BKAUTC" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "AGE" TEXT,
    "ATRF" TEXT,
    "CTYP" TEXT,
    "DANNI" TEXT,
    "DEBUT" TEXT,
    "DEM" TEXT,
    "DEV" TEXT,
    "DEVF" TEXT,
    "DMO" TEXT,
    "DOU" TEXT,
    "DUREE" TEXT,
    "ECH" TEXT,
    "ETA" TEXT,
    "EVE" TEXT,
    "FIN" TEXT,
    "GEHB" TEXT,
    "GLOB" TEXT,
    "MAUT" TEXT,
    "MCOMD" TEXT,
    "MCOMID" TEXT,
    "MCOMIN" TEXT,
    "MCOMN" TEXT,
    "MCOMND" TEXT,
    "MCOMNN" TEXT,
    "MCOMRD" TEXT,
    "MCOMRN" TEXT,
    "MCOMSD" TEXT,
    "MCOMSN" TEXT,
    "MFRD" TEXT,
    "MFRN" TEXT,
    "MOA" TEXT,
    "MTXD" TEXT,
    "MTXN" TEXT,
    "NAT" TEXT,
    "NAUT" TEXT,
    "NCP" TEXT,
    "NCPE" TEXT,
    "NCPF" TEXT,
    "NORD" TEXT,
    "OPE" TEXT,
    "REFC" TEXT,
    "RENOUV" TEXT,
    "SIT" TEXT,
    "SUF" TEXT,
    "SUFE" TEXT,
    "SUFF" TEXT,
    "TCOM" TEXT,
    "TCOMN" TEXT,
    "TCOMR" TEXT,
    "TCOMS" TEXT,
    "TTAX" TEXT,
    "TYP" TEXT,
    "UTA" TEXT,
    "UTF" TEXT,
    "UTI" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_am_BKAUTC"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- Amplitude | Source : Informix.bank.BKCDL | 46 champs métier
CREATE TABLE public."Syncro_am_BKCDL" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "AGE" TEXT,
    "AGE_ENG" TEXT,
    "ATRF" TEXT,
    "AVE" TEXT,
    "CHA" TEXT,
    "CHAP_ENG" TEXT,
    "CHAPC" TEXT,
    "CHAPC_ENG" TEXT,
    "CHAPR" TEXT,
    "CHAPR_ENG" TEXT,
    "CLI" TEXT,
    "CTG" TEXT,
    "DCRCE" TEXT,
    "DECH" TEXT,
    "DEV" TEXT,
    "DEV_ENG" TEXT,
    "DPROV" TEXT,
    "DSTATA" TEXT,
    "DSTATPC" TEXT,
    "DSTATPR" TEXT,
    "ETAB" TEXT,
    "ETAPRV" TEXT,
    "EVE" TEXT,
    "GUIB" TEXT,
    "MCNAT" TEXT,
    "MCRCE" TEXT,
    "MPROV" TEXT,
    "MPRVC" TEXT,
    "NATENG" TEXT,
    "NATREC" TEXT,
    "NATRECPR" TEXT,
    "NCHE" TEXT,
    "NCP" TEXT,
    "NCP_ENG" TEXT,
    "NEFF" TEXT,
    "NUM" TEXT,
    "ORD" TEXT,
    "REFCDL" TEXT,
    "SERIE" TEXT,
    "STATA" TEXT,
    "STATPC" TEXT,
    "STATPR" TEXT,
    "SUF" TEXT,
    "SUF_ENG" TEXT,
    "TYP" TEXT,
    "UTIPRV" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_am_BKCDL"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- Amplitude | Source : Informix.bank.BKCHACDL | 12 champs métier
CREATE TABLE public."Syncro_am_BKCHACDL" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "ATRF" TEXT,
    "CHA_DEC1" TEXT,
    "CHA_DEC2" TEXT,
    "CHA_DEC3" TEXT,
    "CHA_DEC4" TEXT,
    "CHA_DEC5" TEXT,
    "CHA_ORI" TEXT,
    "DMO" TEXT,
    "DOU" TEXT,
    "NATENG" TEXT,
    "TYP" TEXT,
    "UTI" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_am_BKCHACDL"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- Amplitude | Source : Informix.bank.BKCHAP | 25 champs métier
CREATE TABLE public."Syncro_am_BKCHAP" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "ATRF" TEXT,
    "CCHAP" TEXT,
    "CCHQ" TEXT,
    "CCLI" TEXT,
    "CENT" TEXT,
    "CHA" TEXT,
    "CID" TEXT,
    "CRP" TEXT,
    "DMO" TEXT,
    "DOU" TEXT,
    "INT" TEXT,
    "LC1" TEXT,
    "LC2" TEXT,
    "LC3" TEXT,
    "LC4" TEXT,
    "LIB" TEXT,
    "MVTC" TEXT,
    "MVTD" TEXT,
    "REPN" TEXT,
    "SENS" TEXT,
    "SER" TEXT,
    "SOLC" TEXT,
    "SOLD" TEXT,
    "TYPC" TEXT,
    "UTI" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_am_BKCHAP"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- Amplitude | Source : Informix.bank.BKCHCEXCDL_MA | 12 champs métier
CREATE TABLE public."Syncro_am_BKCHCEXCDL_MA" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "AGE" TEXT,
    "ATRF" TEXT,
    "CDEX" TEXT,
    "CLI" TEXT,
    "DEFF" TEXT,
    "DFIN" TEXT,
    "DMO" TEXT,
    "DOU" TEXT,
    "ID_BKCHCEXCDL_MA" TEXT,
    "IMME" TEXT,
    "STAT" TEXT,
    "UTI" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_am_BKCHCEXCDL_MA"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- Amplitude | Source : Informix.bank.BKCLI | 96 champs métier
CREATE TABLE public."Syncro_am_BKCLI" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "ACLAS" TEXT,
    "AGE" TEXT,
    "CAPJ" TEXT,
    "CATL" TEXT,
    "CATN" TEXT,
    "CATR" TEXT,
    "CED" TEXT,
    "CHL1" TEXT,
    "CHL2" TEXT,
    "CHL3" TEXT,
    "CLCR" TEXT,
    "CLI" TEXT,
    "CLIFAM" TEXT,
    "CLIPAR" TEXT,
    "CMC1" TEXT,
    "CMC2" TEXT,
    "CONJ" TEXT,
    "DATC" TEXT,
    "DCAPJ" TEXT,
    "DEPN" TEXT,
    "DICB" TEXT,
    "DICHQ" TEXT,
    "DID" TEXT,
    "DMO" TEXT,
    "DNA" TEXT,
    "DOU" TEXT,
    "DRC" TEXT,
    "DSITJ" TEXT,
    "DVRRC" TEXT,
    "EMTIT" TEXT,
    "EPU" TEXT,
    "FJU" TEXT,
    "GES" TEXT,
    "GRP" TEXT,
    "ICB" TEXT,
    "ICHQ" TEXT,
    "IDEXT" TEXT,
    "LANG" TEXT,
    "LIB" TEXT,
    "LID" TEXT,
    "LIENBQ" TEXT,
    "LOCN" TEXT,
    "LRC" TEXT,
    "LTER" TEXT,
    "LTERC" TEXT,
    "MACLAS" TEXT,
    "MET" TEXT,
    "MIDNAME" TEXT,
    "NAT" TEXT,
    "NBENF" TEXT,
    "NCHC" TEXT,
    "NICR" TEXT,
    "NID" TEXT,
    "NIDF" TEXT,
    "NIDN" TEXT,
    "NIS" TEXT,
    "NJF" TEXT,
    "NMER" TEXT,
    "NOM" TEXT,
    "NOMREST" TEXT,
    "NPA" TEXT,
    "NRC" TEXT,
    "NST" TEXT,
    "OID" TEXT,
    "OPETR" TEXT,
    "ORD" TEXT,
    "PAYN" TEXT,
    "PRE" TEXT,
    "QUA" TEXT,
    "REG" TEXT,
    "REGN" TEXT,
    "RES" TEXT,
    "RESD" TEXT,
    "RRC" TEXT,
    "RSO" TEXT,
    "RSO2" TEXT,
    "SEC" TEXT,
    "SEG" TEXT,
    "SEXT" TEXT,
    "SGRP" TEXT,
    "SIG" TEXT,
    "SIT" TEXT,
    "SITIMMO" TEXT,
    "SITJ" TEXT,
    "SMET" TEXT,
    "TAX" TEXT,
    "TCLI" TEXT,
    "TCONJ" TEXT,
    "TID" TEXT,
    "UTI" TEXT,
    "UTI_VRRC" TEXT,
    "UTIC" TEXT,
    "VID" TEXT,
    "VILN" TEXT,
    "VPA" TEXT,
    "VRC" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_am_BKCLI"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- Amplitude | Source : Informix.bank.BKCOM | 94 champs métier
CREATE TABLE public."Syncro_am_BKCOM" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "AGCHQ" TEXT,
    "AGE" TEXT,
    "AGECRE" TEXT,
    "AGERIB" TEXT,
    "ARR" TEXT,
    "AUT1" TEXT,
    "CATR" TEXT,
    "CFE" TEXT,
    "CHA" TEXT,
    "CLC" TEXT,
    "CLEIBAN" TEXT,
    "CLI" TEXT,
    "CLIR" TEXT,
    "CODADCH" TEXT,
    "CPACK" TEXT,
    "CPL" TEXT,
    "CPRO" TEXT,
    "CPTCOJ" TEXT,
    "CRP" TEXT,
    "CRT" TEXT,
    "CTX" TEXT,
    "CVER" TEXT,
    "DAR" TEXT,
    "DATDEV" TEXT,
    "DATL1" TEXT,
    "DATL2" TEXT,
    "DAUT" TEXT,
    "DAUT2" TEXT,
    "DBT" TEXT,
    "DDC" TEXT,
    "DDD" TEXT,
    "DDL" TEXT,
    "DDM" TEXT,
    "DECH" TEXT,
    "DERNAGE" TEXT,
    "DERNDEV" TEXT,
    "DEV" TEXT,
    "DFE" TEXT,
    "DHI" TEXT,
    "DIF" TEXT,
    "DMO" TEXT,
    "DODB" TEXT,
    "DODB2" TEXT,
    "DOU" TEXT,
    "DVA" TEXT,
    "ECA1" TEXT,
    "ECD" TEXT,
    "ECH" TEXT,
    "EXT" TEXT,
    "EXTD" TEXT,
    "FUS_AGE" TEXT,
    "FUS_CHA" TEXT,
    "FUS_DEV" TEXT,
    "FUS_NCP" TEXT,
    "FUS_SUF" TEXT,
    "IFE" TEXT,
    "INTI" TEXT,
    "LIB" TEXT,
    "MDCHQ" TEXT,
    "MIND" TEXT,
    "MINDS" TEXT,
    "MINJ" TEXT,
    "MINJS" TEXT,
    "MNTL2" TEXT,
    "MOTCLO" TEXT,
    "MTFDR" TEXT,
    "NANTI" TEXT,
    "NCP" TEXT,
    "ORD" TEXT,
    "OUVP" TEXT,
    "PARRC" TEXT,
    "PARRD" TEXT,
    "PRLIB" TEXT,
    "PSBF" TEXT,
    "RIBDEC" TEXT,
    "SAR" TEXT,
    "SBI" TEXT,
    "SDE" TEXT,
    "SER" TEXT,
    "SEUI" TEXT,
    "SHI" TEXT,
    "SIN" TEXT,
    "SUF" TEXT,
    "SVA" TEXT,
    "TADCH" TEXT,
    "TAX" TEXT,
    "TYCHQ" TEXT,
    "TYP" TEXT,
    "UTI" TEXT,
    "UTIC" TEXT,
    "UTIFE" TEXT,
    "UTIIF" TEXT,
    "ZONL2" TEXT,
    "ZONL3" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_am_BKCOM"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- Amplitude | Source : Informix.bank.BKDAR | 81 champs métier
CREATE TABLE public."Syncro_am_BKDAR" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "AGE" TEXT,
    "AGEM" TEXT,
    "AGR" TEXT,
    "ALGF" TEXT,
    "ANNEE" TEXT,
    "BFFIX" TEXT,
    "BICR" TEXT,
    "BICRB" TEXT,
    "BIDB" TEXT,
    "BIDBA" TEXT,
    "BIDBR" TEXT,
    "CALD" TEXT,
    "CDEC" TEXT,
    "CHA" TEXT,
    "CLI" TEXT,
    "CMDI" TEXT,
    "CMDS" TEXT,
    "DEV" TEXT,
    "DEVM" TEXT,
    "GES" TEXT,
    "INTERMED" TEXT,
    "MCMVT" TEXT,
    "MFFIX" TEXT,
    "MFIX" TEXT,
    "MICR" TEXT,
    "MIDB" TEXT,
    "MIN_PDB" TEXT,
    "MODE_SEUIL" TEXT,
    "MOIS" TEXT,
    "MOYEN" TEXT,
    "MPLFIX" TEXT,
    "MPLIB" TEXT,
    "MPLIBB" TEXT,
    "MRET" TEXT,
    "MTDC" TEXT,
    "MVTDI" TEXT,
    "MVTDS" TEXT,
    "NB_DB" TEXT,
    "NBFIX" TEXT,
    "NBJD" TEXT,
    "NCP" TEXT,
    "NCPM" TEXT,
    "NET" TEXT,
    "NETC" TEXT,
    "OPG" TEXT,
    "PDEC1" TEXT,
    "PDEC2" TEXT,
    "PDEC3" TEXT,
    "PFIX" TEXT,
    "PLFCPT" TEXT,
    "PLFDEC" TEXT,
    "PLFMY" TEXT,
    "RAZ" TEXT,
    "RECALC" TEXT,
    "RET" TEXT,
    "RIDB" TEXT,
    "RIDEC" TEXT,
    "RIMVT" TEXT,
    "SAR" TEXT,
    "SEUIL_FR" TEXT,
    "SEUIL_IDB" TEXT,
    "SLDMY" TEXT,
    "SOLDE" TEXT,
    "SUF" TEXT,
    "SUFM" TEXT,
    "TAX" TEXT,
    "TCMVT" TEXT,
    "TCR" TEXT,
    "TEG" TEXT,
    "TFFIX" TEXT,
    "TFFUS" TEXT,
    "TMDI" TEXT,
    "TMDS" TEXT,
    "TPLFDEC" TEXT,
    "TTDC" TEXT,
    "TUSR" TEXT,
    "TVAREC" TEXT,
    "TXDEC" TEXT,
    "TYP" TEXT,
    "TYPA" TEXT,
    "TYPD" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_am_BKDAR"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- Amplitude | Source : Informix.bank.BKHCCOM | 13 champs métier
CREATE TABLE public."Syncro_am_BKHCCOM" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "AGE" TEXT,
    "ANCHA" TEXT,
    "ATRF" TEXT,
    "DCHGT" TEXT,
    "DEV" TEXT,
    "DSDE" TEXT,
    "MODU" TEXT,
    "NCP" TEXT,
    "NOCHA" TEXT,
    "NORD" TEXT,
    "SDE" TEXT,
    "SUF" TEXT,
    "UTI" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_am_BKHCCOM"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- Amplitude | Source : Informix.bank.BKHIS | 50 champs métier
CREATE TABLE public."Syncro_am_BKHIS" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "AGDE" TEXT,
    "AGE" TEXT,
    "AGEM" TEXT,
    "AGSA" TEXT,
    "CETICPT" TEXT,
    "CPL" TEXT,
    "DAG" TEXT,
    "DCO" TEXT,
    "DDL" TEXT,
    "DECH" TEXT,
    "DES1" TEXT,
    "DES2" TEXT,
    "DES3" TEXT,
    "DES4" TEXT,
    "DES5" TEXT,
    "DEV" TEXT,
    "DEVC" TEXT,
    "DEXA" TEXT,
    "DIN" TEXT,
    "DVA" TEXT,
    "ETA" TEXT,
    "EVE" TEXT,
    "EXO" TEXT,
    "FUSION" TEXT,
    "IDEN" TEXT,
    "LABEL" TEXT,
    "LIB" TEXT,
    "MAR" TEXT,
    "MCTV" TEXT,
    "MODU" TEXT,
    "MON" TEXT,
    "MVT" TEXT,
    "NAT" TEXT,
    "NCC" TEXT,
    "NCP" TEXT,
    "NOSEQ" TEXT,
    "OPE" TEXT,
    "PIE" TEXT,
    "PIEO" TEXT,
    "REFDOS" TEXT,
    "RLET" TEXT,
    "SCHEMA" TEXT,
    "SEN" TEXT,
    "SER" TEXT,
    "SUC" TEXT,
    "SUF" TEXT,
    "UTA" TEXT,
    "UTF" TEXT,
    "UTI" TEXT,
    "UTL" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_am_BKHIS"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- LS | Source : Oracle.LSCMPLI.AUTORISATION | 14 champs métier
CREATE TABLE public."Syncro_Ls_AUTORISATION" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "AUTORISATION_ID" TEXT,
    "CATEGORIE" TEXT,
    "DATE_EFFET" TEXT,
    "DATE_FIN_UTILISATION" TEXT,
    "DISPONIBLE" TEXT,
    "ENCOURS" TEXT,
    "ENGAGEMENT_CODE_SOCIETE" TEXT,
    "ENGAGEMENT_NUMERO_DOSSIER" TEXT,
    "MONTANT" TEXT,
    "NUM_AUTORISATION" TEXT,
    "RECHARGEABLE" TEXT,
    "SITUATION" TEXT,
    "TAUX_INTERET" TEXT,
    "TYPE_UTILISATION" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_Ls_AUTORISATION"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- LS | Source : Oracle.LSCMPLI.COMPTE | 14 champs métier
CREATE TABLE public."Syncro_Ls_COMPTE" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "AUTORISATION_AUTORISATION_ID" TEXT,
    "CODE_REPARTITION" TEXT,
    "COMPTE_ID" TEXT,
    "ENGAGEMENT_CODE_SOCIETE" TEXT,
    "ENGAGEMENT_NUMERO_DOSSIER" TEXT,
    "MODE_REGLEMENT" TEXT,
    "NUM_COMPTE" TEXT,
    "NUM_ORDRE" TEXT,
    "NUM_PAYEUR" TEXT,
    "NUMERO_CLIENT" TEXT,
    "PAM_PAM_ID" TEXT,
    "POURCENTAGE_REPARTITION" TEXT,
    "TIRAGE_TIRAGE_ID" TEXT,
    "TYPE_COMPTE" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_Ls_COMPTE"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- LS | Source : Oracle.LSCMPLI.ENGAGEMENT | 18 champs métier
CREATE TABLE public."Syncro_Ls_ENGAGEMENT" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "CATEGORIE_PRET" TEXT,
    "CODE_AGENCE" TEXT,
    "CODE_OBJET" TEXT,
    "CODE_PRODUIT" TEXT,
    "CODE_SOCIETE" TEXT,
    "DATE_ACCORD" TEXT,
    "DATE_CREATION" TEXT,
    "DATE_LIMITE_MEG" TEXT,
    "DATE_MEG" TEXT,
    "DEVISE" TEXT,
    "MONTANT_ENGAGEMENT" TEXT,
    "MONTANT_IMPAYE_GLOBAL" TEXT,
    "NUMERO_DOSSIER" TEXT,
    "REFERENCE_EMPRUNTEUR" TEXT,
    "SITUATION_DEFAUT" TEXT,
    "SITUATION_DOSSIER" TEXT,
    "SOMME_RESTANT_DUE" TEXT,
    "TYPE_CONTRAT" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_Ls_ENGAGEMENT"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- LS | Source : Oracle.LSCMPLI.ENGAGEMENT_COUVERT | 7 champs métier
CREATE TABLE public."Syncro_Ls_ENGAGEMENT_COUVERT" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "CODE_FILIERE" TEXT,
    "GARANTIE_CODE_SOCIETE" TEXT,
    "GARANTIE_NUMERO_GARANTIE" TEXT,
    "NATURE_ENGAGEMENT" TEXT,
    "NUMERO_COUVERTURE" TEXT,
    "QUOTE_PART" TEXT,
    "TYPE_COUVERTURE" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_Ls_ENGAGEMENT_COUVERT"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- LS | Source : Oracle.LSCMPLI.EVT_REGLEMENT_IMPAYE | 18 champs métier
CREATE TABLE public."Syncro_Ls_EVT_REGLEMENT_IMPAYE" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "CODE_UTILISATEUR" TEXT,
    "COMPTE_REGLEMENT" TEXT,
    "DATE_ECHEANCE" TEXT,
    "DATE_EVT" TEXT,
    "DATE_TRAITEMENT" TEXT,
    "DATE_VALEUR" TEXT,
    "EVT_ID" TEXT,
    "MODE_REGLEMENT" TEXT,
    "MONTANT_REGLEMENT" TEXT,
    "NUM_PAYEUR" TEXT,
    "PAM_PAM_ID" TEXT,
    "REF_PLAN" TEXT,
    "REF_PRELEVEMENT_CLIENT" TEXT,
    "REGLEMENT_ACCESSOIRE" TEXT,
    "REGLEMENT_ASSURANCE" TEXT,
    "REGLEMENT_CAPITAL" TEXT,
    "REGLEMENT_INTERET" TEXT,
    "REGLEMENT_IR" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_Ls_EVT_REGLEMENT_IMPAYE"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- LS | Source : Oracle.LSCMPLI.GAR_APPORTEUR | 2 champs métier
CREATE TABLE public."Syncro_Ls_GAR_APPORTEUR" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "APPORTEUR_ID" TEXT,
    "NUMERO_TIERS" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_Ls_GAR_APPORTEUR"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- LS | Source : Oracle.LSCMPLI.GAR_CLIENT | 2 champs métier
CREATE TABLE public."Syncro_Ls_GAR_CLIENT" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "CLIENT_ID" TEXT,
    "NUMERO_TIERS" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_Ls_GAR_CLIENT"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- LS | Source : Oracle.LSCMPLI.GAR_GARANT | 2 champs métier
CREATE TABLE public."Syncro_Ls_GAR_GARANT" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "GARANT_ID" TEXT,
    "NUMERO_TIERS" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_Ls_GAR_GARANT"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- LS | Source : Oracle.LSCMPLI.IMPAYE | 19 champs métier
CREATE TABLE public."Syncro_Ls_IMPAYE" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "BASE_CALCUL_IR" TEXT,
    "DATE_DERNIER_REGLEMENT_PARTIEL" TEXT,
    "DATE_ECHEANCE" TEXT,
    "DATE_MISE_IMPAYE" TEXT,
    "IMPAYE_ACCESSOIRE_TTC" TEXT,
    "IMPAYE_ASSURANCE_TTC" TEXT,
    "IMPAYE_CAPITAL" TEXT,
    "IMPAYE_ID" TEXT,
    "IMPAYE_INTERET_TTC" TEXT,
    "IMPAYE_IR_TTC" TEXT,
    "MONTANT_IMPAYE_TTC" TEXT,
    "MONTANT_REGLEMENT_PARTIEL" TEXT,
    "MOTIF_IMPAYE" TEXT,
    "PAM_PAM_ID" TEXT,
    "PAYEUR" TEXT,
    "REFERENCE_PLAN_RATTRAPAGE" TEXT,
    "SITUATION_ECHEANCE" TEXT,
    "TAUX_IR" TEXT,
    "TVA_IMPAYE_IR" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_Ls_IMPAYE"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- LS | Source : Oracle.LSCMPLI.NOTAIRE | 15 champs métier
CREATE TABLE public."Syncro_Ls_NOTAIRE" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "BATIMENT" TEXT,
    "CODE_POSTAL" TEXT,
    "ETAGE_SERVICE" TEXT,
    "ID_ETUDE_NOTARIALE" TEXT,
    "IND_ACTIVITE" TEXT,
    "LIEU_DIT" TEXT,
    "LOCALITE" TEXT,
    "NOM" TEXT,
    "NOTAIRE_ID" TEXT,
    "NUMERO_TIERS" TEXT,
    "NUMERO_VOIE" TEXT,
    "PAYS" TEXT,
    "PRENOM" TEXT,
    "TEL_FIXE" TEXT,
    "TEL_PORTABLE" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_Ls_NOTAIRE"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();

-- LS | Source : Oracle.LSCMPLI.PAM | 59 champs métier
CREATE TABLE public."Syncro_Ls_PAM" (
    syncro_reference TEXT PRIMARY KEY CHECK (btrim(syncro_reference) <> ''),
    syncro_date_creation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_update TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    syncro_date_synchronisation TIMESTAMPTZ NOT NULL DEFAULT clock_timestamp(),
    "ACCESSOIRE_CAPITALISE_RESTANT_DU" TEXT,
    "ACCESSOIRE_PROCHAINE_ECHEANCE" TEXT,
    "ASSURANCE_CAPITALISE_RESTANT_DU" TEXT,
    "ASSURANCE_PROCHAINE_ECHEANCE" TEXT,
    "BASE_CALCUL_INTERET" TEXT,
    "BASE_INDEXATION" TEXT,
    "CALCUL_JOUR_EXACT" TEXT,
    "CAPITAL_PROCHAINE_ECHEANCE" TEXT,
    "CAPITAL_RESTANT_DU" TEXT,
    "CODE_ENGAGEMENT" TEXT,
    "CODE_GESTION_MODALITE_RETARD" TEXT,
    "COMPLEMENT_TAUX" TEXT,
    "CONSTANTE_REMB" TEXT,
    "CUMUL_AMORTISSEMENT" TEXT,
    "CUMUL_INTERET_PERCU" TEXT,
    "DATE_DERNIERE_ECHEANCE" TEXT,
    "DATE_DERNIERE_MODIFICATION" TEXT,
    "DATE_FIN_PRET" TEXT,
    "DATE_FIN_PRET_INITIALE" TEXT,
    "DATE_PREMIERE_ECHEANCE" TEXT,
    "DATE_PROCHAINE_ECHEANCE" TEXT,
    "DATE_PROCHAINE_REVISION_TAUX" TEXT,
    "DUREE_PRET" TEXT,
    "DUREE_RESTANTE" TEXT,
    "ENGAGEMENT_CODE_SOCIETE" TEXT,
    "ENGAGEMENT_NUMERO_DOSSIER" TEXT,
    "IMPAYE_ACCESSOIRE" TEXT,
    "IMPAYE_ASSURANCE" TEXT,
    "IMPAYE_CAPITAL" TEXT,
    "IMPAYE_INTERET" TEXT,
    "IMPAYE_IR" TEXT,
    "INTERET_CAPITALISE_RESTANT_DU" TEXT,
    "INTERET_COURU_NON_ECHU" TEXT,
    "INTERET_ECHU_NON_COURUS" TEXT,
    "INTERET_PROCHAINE_ECHEANCE" TEXT,
    "MONTANT_RESTANT_A_DEBLOQUER" TEXT,
    "MONTANT_RISTOURNE" TEXT,
    "MONTANT_TOTAL_DEBLOQUE" TEXT,
    "MOTIF_SOLDE_DOSSIER" TEXT,
    "NB_ECHEANCE" TEXT,
    "NB_ECHEANCE_ECHUE" TEXT,
    "NB_ECHEANCE_RESTANTE" TEXT,
    "NB_IMPAYE" TEXT,
    "NB_PALIER_RESTANT" TEXT,
    "NB_TERME_RESTANT_DANS_PALIER" TEXT,
    "NB_TOTAL_PALIER" TEXT,
    "NUM_PALIER_COURANT" TEXT,
    "NUM_PROCHAINE_ECHEANCE" TEXT,
    "PAM_ID" TEXT,
    "PERIODICITE" TEXT,
    "PERIODICITE_REVISION_TAUX" TEXT,
    "TAUX_INTERET_COURANT" TEXT,
    "TAUX_INTERET_RETARD" TEXT,
    "TAUX_RISTOURNE" TEXT,
    "TAUX_TAXE" TEXT,
    "TAXE_CUMUL_INTERET_PERCU" TEXT,
    "TEG" TEXT,
    "TYPE_PALIER_COURANT" TEXT,
    "TYPE_TAUX" TEXT
);
CREATE TRIGGER trg_syncro_date_update
BEFORE UPDATE ON public."Syncro_Ls_PAM"
FOR EACH ROW EXECUTE FUNCTION public.gdd_syncro_maj_date_update();
