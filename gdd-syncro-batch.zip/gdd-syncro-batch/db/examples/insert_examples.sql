-- DEV/RECETTE uniquement : un exemple fictif par table.
BEGIN;
INSERT INTO public."Syncro_am_BKAGE" (syncro_reference, "AGE", "LIB")
VALUES ('Syncro_am_BKAGE_DEMO_001', '00001', 'Agence démonstration')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_am_BKAUTC" (syncro_reference, "AGE", "NCP", "MAUT", "DEV")
VALUES ('Syncro_am_BKAUTC_DEMO_001', '00001', '00000000001', '50000.00', 'MAD')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_am_BKCDL" (syncro_reference, "AGE", "CLI", "NCP", "REFCDL")
VALUES ('Syncro_am_BKCDL_DEMO_001', '00001', 'CLI_DEMO_001', '00000000001', 'CDL_DEMO_001')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_am_BKCHACDL" (syncro_reference, "CHA_ORI", "TYP")
VALUES ('Syncro_am_BKCHACDL_DEMO_001', 'CHA_DEMO_001', 'DEMO')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_am_BKCHAP" (syncro_reference, "CHA", "LIB")
VALUES ('Syncro_am_BKCHAP_DEMO_001', 'CHA_DEMO_001', 'Chapitre de démonstration')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_am_BKCHCEXCDL_MA" (syncro_reference, "ID_BKCHCEXCDL_MA", "AGE", "CLI")
VALUES ('Syncro_am_BKCHCEXCDL_MA_DEMO_001', '1', '00001', 'CLI_DEMO_001')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_am_BKCLI" (syncro_reference, "CLI", "AGE", "NOM", "PRE")
VALUES ('Syncro_am_BKCLI_DEMO_001', 'CLI_DEMO_001', '00001', 'CLIENT FICTIF', 'DEMO')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_am_BKCOM" (syncro_reference, "AGE", "CLI", "NCP", "DEV", "LIB")
VALUES ('Syncro_am_BKCOM_DEMO_001', '00001', 'CLI_DEMO_001', '00000000001', 'MAD', 'Compte de démonstration')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_am_BKDAR" (syncro_reference, "AGE", "CLI", "NCP", "ANNEE", "MOIS", "SOLDE")
VALUES ('Syncro_am_BKDAR_DEMO_001', '00001', 'CLI_DEMO_001', '00000000001', '2026', '10', '1500.00')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_am_BKHCCOM" (syncro_reference, "AGE", "NCP", "DCHGT")
VALUES ('Syncro_am_BKHCCOM_DEMO_001', '00001', '00000000001', '2026-10-12')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_am_BKHIS" (syncro_reference, "AGE", "NCP", "MON", "DEV", "LIB")
VALUES ('Syncro_am_BKHIS_DEMO_001', '00001', '00000000001', '250.00', 'MAD', 'Opération fictive')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_Ls_AUTORISATION" (syncro_reference, "AUTORISATION_ID", "NUM_AUTORISATION", "MONTANT", "ENGAGEMENT_CODE_SOCIETE", "ENGAGEMENT_NUMERO_DOSSIER")
VALUES ('Syncro_Ls_AUTORISATION_DEMO_001', '1', 'AUT_DEMO_001', '50000.00', 'DEMO', 'DOS_DEMO_001')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_Ls_COMPTE" (syncro_reference, "COMPTE_ID", "NUM_COMPTE", "NUMERO_CLIENT", "AUTORISATION_AUTORISATION_ID", "PAM_PAM_ID")
VALUES ('Syncro_Ls_COMPTE_DEMO_001', '1', '00000000001', 'CLI_DEMO_001', '1', '1')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_Ls_ENGAGEMENT" (syncro_reference, "CODE_SOCIETE", "NUMERO_DOSSIER", "REFERENCE_EMPRUNTEUR", "DATE_CREATION", "DEVISE", "MONTANT_ENGAGEMENT")
VALUES ('Syncro_Ls_ENGAGEMENT_DEMO_001', 'DEMO', 'DOS_DEMO_001', 'CLI_DEMO_001', '2026-10-12', 'MAD', '50000.00')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_Ls_ENGAGEMENT_COUVERT" (syncro_reference, "NUMERO_COUVERTURE", "GARANTIE_CODE_SOCIETE", "GARANTIE_NUMERO_GARANTIE", "QUOTE_PART")
VALUES ('Syncro_Ls_ENGAGEMENT_COUVERT_DEMO_001', 'COUV_DEMO_001', 'DEMO', 'GAR_DEMO_001', '100')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_Ls_EVT_REGLEMENT_IMPAYE" (syncro_reference, "EVT_ID", "PAM_PAM_ID", "DATE_EVT", "MONTANT_REGLEMENT")
VALUES ('Syncro_Ls_EVT_REGLEMENT_IMPAYE_DEMO_001', '1', '1', '2026-10-12', '250.00')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_Ls_GAR_APPORTEUR" (syncro_reference, "APPORTEUR_ID", "NUMERO_TIERS")
VALUES ('Syncro_Ls_GAR_APPORTEUR_DEMO_001', '1', 'TIERS_DEMO_001')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_Ls_GAR_CLIENT" (syncro_reference, "CLIENT_ID", "NUMERO_TIERS")
VALUES ('Syncro_Ls_GAR_CLIENT_DEMO_001', '1', 'TIERS_DEMO_001')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_Ls_GAR_GARANT" (syncro_reference, "GARANT_ID", "NUMERO_TIERS")
VALUES ('Syncro_Ls_GAR_GARANT_DEMO_001', '1', 'TIERS_DEMO_002')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_Ls_IMPAYE" (syncro_reference, "IMPAYE_ID", "PAM_PAM_ID", "DATE_ECHEANCE", "MONTANT_IMPAYE_TTC")
VALUES ('Syncro_Ls_IMPAYE_DEMO_001', '1', '1', '2026-10-01', '1500.00')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_Ls_NOTAIRE" (syncro_reference, "NOTAIRE_ID", "NUMERO_TIERS", "NOM", "PRENOM")
VALUES ('Syncro_Ls_NOTAIRE_DEMO_001', '1', 'TIERS_DEMO_003', 'NOTAIRE FICTIF', 'DEMO')
ON CONFLICT (syncro_reference) DO NOTHING;

INSERT INTO public."Syncro_Ls_PAM" (syncro_reference, "PAM_ID", "ENGAGEMENT_CODE_SOCIETE", "ENGAGEMENT_NUMERO_DOSSIER", "CAPITAL_RESTANT_DU", "TAUX_INTERET_COURANT")
VALUES ('Syncro_Ls_PAM_DEMO_001', '1', 'DEMO', 'DOS_DEMO_001', '45000.00', '5.50')
ON CONFLICT (syncro_reference) DO NOTHING;

COMMIT;
