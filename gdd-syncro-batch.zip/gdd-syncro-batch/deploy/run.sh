#!/usr/bin/env bash
set -euo pipefail
GDD_APP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$GDD_APP_DIR"
exec java -Xms128m -Xmx512m -jar "$GDD_APP_DIR/dist/gdd-syncro-batch-1.0.0.jar" "$@"
