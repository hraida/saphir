package com.saham.api.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

/**
 * Requête de mainlevée d'un nantissement NARSA.
 *
 * <p>Ce DTO permet de lever (annuler) un nantissement existant
 * lorsqu'un contrat de financement est soldé ou clôturé.
 *
 * <p>La mainlevée rend le véhicule libre de toute sûreté
 * auprès de NARSA.
 */
@Schema(
    name = "NantissementLeverRequest",
    description = "Données nécessaires à la mainlevée d'un nantissement auprès de NARSA"
)
public class NantissementLeverRequest {

  /**
   * Identifiant unique de la requête.
   *
   * <p>Utilisé pour la traçabilité, la corrélation des logs
   * et le suivi des échanges avec NARSA.
   */
  @Schema(
      description = "Identifiant unique de la requête (corrélation)",
      example = "c21d9e4f-9dcb-4d7a-9a2f-1b6a8d2a9c10"
  )
  @NotBlank(message = "idRequete est obligatoire")
  public String idRequete;

  /**
   * Code de la Société de Financement (SF).
   *
   * <p>Identifie l'organisme financier demandant la mainlevée.
   */
  @Schema(
      description = "Code de la société de financement",
      example = "SAHAM"
  )
  @NotBlank(message = "codeSF est obligatoire")
  public String codeSF;

  /**
   * Numéro du contrat de financement.
   *
   * <p>Référence interne du contrat de crédit
   * associé au véhicule.
   */
  @Schema(
      description = "Numéro du contrat de financement",
      example = "CNTR-2024-001245"
  )
  @NotBlank(message = "numContrat est obligatoire")
  public String numContrat;

  /**
   * Numéro de châssis (VIN) du véhicule.
   *
   * <p>Identifiant unique international du véhicule
   * permettant de retrouver le nantissement.
   */
  @Schema(
      description = "Numéro de châssis (VIN)",
      example = "VF1RFA00412345678"
  )
  @NotBlank(message = "numChassis est obligatoire")
  public String numChassis;

  /**
   * Date effective de la mainlevée.
   *
   * <p>Correspond généralement à la date de clôture
   * ou de solde du contrat.
   *
   * <p>Format attendu : {@code yyyy-MM-dd}.
   */
  @Schema(
      description = "Date de la mainlevée (format yyyy-MM-dd)",
      example = "2024-11-30"
  )
  @NotBlank(message = "dateMainlevee est obligatoire")
  @Pattern(
      regexp = "^\\d{4}-\\d{2}-\\d{2}$",
      message = "dateMainlevee doit respecter le format yyyy-MM-dd"
  )
  public String dateMainlevee;
}
