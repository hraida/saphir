package com.saham.api.exception;

import org.springframework.http.HttpStatus;

public class NarsaBusinessException extends RuntimeException {
  private final String idRequete;
  private final String codeMetier;
  private final HttpStatus httpStatus;

  public NarsaBusinessException(String idRequete, String codeMetier, HttpStatus httpStatus, String message) {
    super(message);
    this.idRequete = idRequete;
    this.codeMetier = codeMetier;
    this.httpStatus = httpStatus;
  }

  public String getIdRequete() { return idRequete; }
  public String getCodeMetier() { return codeMetier; }
  public HttpStatus getHttpStatus() { return httpStatus; }

  public static NarsaBusinessException d400(String id, String msg) { return new NarsaBusinessException(id, "D400", HttpStatus.BAD_REQUEST, msg); }
  public static NarsaBusinessException d401(String id, String msg) { return new NarsaBusinessException(id, "D401", HttpStatus.NOT_ACCEPTABLE, msg); }
  public static NarsaBusinessException d402(String id, String msg) { return new NarsaBusinessException(id, "D402", HttpStatus.NOT_ACCEPTABLE, msg); }
  public static NarsaBusinessException d403(String id, String msg) { return new NarsaBusinessException(id, "D403", HttpStatus.NOT_ACCEPTABLE, msg); }
  public static NarsaBusinessException d404(String id, String msg) { return new NarsaBusinessException(id, "D404", HttpStatus.NOT_ACCEPTABLE, msg); }
  public static NarsaBusinessException d301(String id, String msg) { return new NarsaBusinessException(id, "D301", HttpStatus.NOT_ACCEPTABLE, msg); }
}
