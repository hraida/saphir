package com.saham.api.service;

import com.saham.api.dto.AuthRequest;
import com.saham.api.dto.AuthResponse;
import com.saham.api.exception.NarsaBusinessException;
import com.saham.api.store.TokenStore;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.HexFormat;
import java.util.UUID;

@Service
public class NarsaAuthService {

  private final TokenStore tokenStore;
  private final Clock clock;

  @Value("${mock.narsa.username}") private String username;
  @Value("${mock.narsa.secret}") private String secret;
  @Value("${mock.narsa.xTokenTtlMinutes:30}") private long xTokenTtlMin;

  private static final DateTimeFormatter EXP_FMT = DateTimeFormatter.ISO_OFFSET_DATE_TIME;

  public NarsaAuthService(TokenStore tokenStore, Clock clock) {
    this.tokenStore = tokenStore;
    this.clock = clock;
  }

  public AuthResponse authenticate(AuthRequest req) {
    if (req == null || req.UserName() == null || req.Password() == null) {
      throw NarsaBusinessException.d400(null, "Missing credentials");
    }
    if (!username.equals(req.UserName())) {
      throw NarsaBusinessException.d400(null, "Invalid username");
    }

    String today = LocalDate.now(clock).format(DateTimeFormatter.BASIC_ISO_DATE);
    String expected = sha256Hex("NARSA-APSF" + today + secret);
    if (!expected.equalsIgnoreCase(req.Password())) {
      throw NarsaBusinessException.d400(null, "Invalid password hash");
    }

    String xToken = "xtoken_" + UUID.randomUUID();
    Instant exp = Instant.now(clock).plus(xTokenTtlMin, java.time.temporal.ChronoUnit.MINUTES);
    tokenStore.putXToken(xToken, exp);

    String idToken = UUID.randomUUID().toString();
    String expIso = OffsetDateTime.ofInstant(exp, ZoneId.systemDefault()).format(EXP_FMT);

    return new AuthResponse(true, "Authentifié avec succès", new AuthResponse.Token(idToken, xToken, expIso));
  }

  private static String sha256Hex(String input) {
    try {
      MessageDigest md = MessageDigest.getInstance("SHA-256");
      byte[] hash = md.digest(input.getBytes(StandardCharsets.UTF_8));
      return HexFormat.of().formatHex(hash);
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }
}
