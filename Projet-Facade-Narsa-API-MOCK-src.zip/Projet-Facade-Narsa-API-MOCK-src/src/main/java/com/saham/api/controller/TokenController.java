package com.saham.api.controller;

import com.saham.api.service.OauthTokenService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Controller OAuth Token.
 *
 * <p>
 * Expose l’endpoint standard OAuth 2.0 permettant d’émettre un token d’accès
 * via le mécanisme <b>Client Credentials</b>.
 *
 * <p>
 * Ce endpoint est utilisé par les applications backend pour obtenir un access
 * token avant d’appeler des APIs protégées.
 *
 * <p>
 * <b>Important :</b> Cette implémentation respecte le contrat OAuth standard
 * (RFC 6749).
 */
@RestController
@Tag(name = "OAuth Token", description = "Endpoint OAuth 2.0 pour l’émission de tokens (Client Credentials)")
public class TokenController {

	private final OauthTokenService service;

	public TokenController(OauthTokenService service) {
		this.service = service;
	}

	/**
	 * Émission d’un token OAuth.
	 *
	 * <p>
	 * Ce endpoint permet d’obtenir un access token OAuth en utilisant :
	 * <ul>
	 * <li>Une authentification via le header {@code Authorization}</li>
	 * <li>Le paramètre {@code grant_type} (client_credentials)</li>
	 * <li>Le paramètre {@code scope}</li>
	 * </ul>
	 *
	 * @param authorization Header Authorization (Basic
	 *                      base64(clientId:clientSecret))
	 * @param grantType     Type de grant OAuth (ex: client_credentials)
	 * @param scope         Scope(s) demandés
	 * @return Map contenant l’access token et ses métadonnées
	 */
	@Operation(summary = "Émission d’un token OAuth", description = "Retourne un access token OAuth 2.0 via le mécanisme Client Credentials.")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Token émis avec succès"),
			@ApiResponse(responseCode = "400", description = "Requête invalide (grant_type ou scope incorrect)"),
			@ApiResponse(responseCode = "401", description = "Non autorisé (credentials invalides)"),
			@ApiResponse(responseCode = "500", description = "Erreur interne") })
	@PostMapping(value = "/token", consumes = "application/x-www-form-urlencoded")
	public Map<String, Object> token(

			@Parameter(description = "Header Authorization en Basic (base64(clientId:clientSecret))", required = true, example = "Basic Y2xpZW50SWQ6Y2xpZW50U2VjcmV0") @RequestHeader("Authorization") String authorization,

			@Parameter(description = "Type de grant OAuth", required = true, example = "client_credentials") @RequestParam("grant_type") String grantType,

			@Parameter(description = "Scope(s) demandé(s)", required = true, example = "narsa.read narsa.write") @RequestParam("scope") String scope) {
		return service.issue(authorization, grantType, scope);
	}
}
