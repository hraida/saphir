package com.saham.api.service;

import com.saham.api.dto.*;
import com.saham.api.entity.Nantissement;
import com.saham.api.exception.NarsaBusinessException;
import com.saham.api.repo.NantissementRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class NantissementService {

  private final NantissementRepository repo;

  public NantissementService(NantissementRepository repo) {
    this.repo = repo;
  }

  @Transactional
  public ApiResponse creer(NantissementCreateRequest r) {
    validateCreate(r);

    Nantissement existingByChassis = repo.findFirstByNumChassis(r.numChassis).orElse(null);
    Nantissement existingTriplet = repo.findByCodeSFAndNumContratAndNumChassis(r.codeSF, r.numContrat, r.numChassis).orElse(null);

    if (existingByChassis != null && !existingByChassis.getCodeSF().equals(r.codeSF)) {
      throw NarsaBusinessException.d401(r.idRequete, "Véhicule déjà soumis par un autre organisme");
    }
    if (existingByChassis != null && existingByChassis.getCodeSF().equals(r.codeSF) && !existingByChassis.getNumContrat().equals(r.numContrat)) {
      throw NarsaBusinessException.d402(r.idRequete, "Véhicule déjà nanti par la même SF sous un autre contrat");
    }
    if (existingTriplet != null) {
      throw NarsaBusinessException.d404(r.idRequete, "Nantissement déjà déclaré");
    }

    if (r.numWW == null && (r.immatVeh1 == null || r.immatVeh2 == null || r.immatVeh3 == null)) {
      throw NarsaBusinessException.d403(r.idRequete, "Incohérence châssis et matricule");
    }

    Nantissement n = new Nantissement();
    n.setCodeSF(r.codeSF);
    n.setNumContrat(r.numContrat);
    n.setNumChassis(r.numChassis);
    n.setNumWW(r.numWW);
    n.setImmatVeh1(r.immatVeh1);
    n.setImmatVeh2(r.immatVeh2);
    n.setImmatVeh3(r.immatVeh3);
    n.setTypeVehicule(r.typeVehicule);
    n.setDateNantissement(r.dateNantissement);
    n.setMainLevee(false);

    repo.save(n);
    return new ApiResponse(r.idRequete, "201", "D201 : Demande de nantissement créée");
  }

  @Transactional(readOnly = true)
  public ConsultResponse consulter(NantissementConsultRequest r) {
    validateConsult(r);

    Nantissement n = repo.findFirstByNumChassis(r.numChassis).orElse(null);
    if (n == null) {
      throw NarsaBusinessException.d402(r.idRequete, "Véhicule inexistant");
    }
    if (n.isMainLevee()) {
      throw NarsaBusinessException.d403(r.idRequete, "Véhicule non nanti");
    }
    if (!n.getCodeSF().equals(r.codeSF)) {
      throw NarsaBusinessException.d401(r.idRequete, "Véhicule sans lien de nantissement avec SF déclarant");
    }

    return new ConsultResponse(
        r.idRequete, "200", "D200 : Succès de consultation",
        n.getNumContrat(), n.getNumWW(), n.getImmatVeh1(), n.getImmatVeh2(), n.getImmatVeh3(),
        n.getTypeVehicule(), n.getNumChassis(), n.getDateNantissement()
    );
  }

  @Transactional
  public ApiResponse lever(NantissementLeverRequest r) {
    validateLever(r);

    Nantissement n = repo.findByCodeSFAndNumContratAndNumChassis(r.codeSF, r.numContrat, r.numChassis).orElse(null);
    if (n == null) {
      throw NarsaBusinessException.d401(r.idRequete, "Mainlevée impossible car véhicule non nanti");
    }
    if (n.isMainLevee()) {
      throw NarsaBusinessException.d301(r.idRequete, "Mainlevée déjà déclarée");
    }

    n.setMainLevee(true);
    repo.save(n);

    return new ApiResponse(r.idRequete, "201", "D201 : Demande de mainlevée créée avec succès");
  }

  private static void validateCreate(NantissementCreateRequest r) {
    String id = (r == null) ? null : r.idRequete;
    if (r == null || isBlank(r.idRequete) || isBlank(r.codeSF) || isBlank(r.numContrat) || isBlank(r.numChassis)
        || isBlank(r.typeVehicule) || isBlank(r.dateNantissement)) {
      throw NarsaBusinessException.d400(id, "Manque d’information");
    }
    boolean hasWw = r.numWW != null;
    boolean hasMat = (r.immatVeh1 != null || r.immatVeh2 != null || r.immatVeh3 != null);
    if (hasWw && hasMat) {
      throw NarsaBusinessException.d400(id, "WW et matricule ne peuvent pas être renseignés simultanément");
    }
  }

  private static void validateConsult(NantissementConsultRequest r) {
    String id = (r == null) ? null : r.idRequete;
    if (r == null || isBlank(r.idRequete) || isBlank(r.codeSF) || isBlank(r.numContrat)
        || isBlank(r.numChassis) || isBlank(r.typeVehicule) || isBlank(r.dateNantissement)) {
      throw NarsaBusinessException.d400(id, "Requête erronée");
    }
  }

  private static void validateLever(NantissementLeverRequest r) {
    String id = (r == null) ? null : r.idRequete;
    if (r == null || isBlank(r.idRequete) || isBlank(r.codeSF) || isBlank(r.numContrat)
        || isBlank(r.numChassis) || isBlank(r.dateMainlevee)) {
      throw NarsaBusinessException.d400(id, "Manque d’information");
    }
  }

  private static boolean isBlank(String s) { return s == null || s.trim().isEmpty(); }
}
