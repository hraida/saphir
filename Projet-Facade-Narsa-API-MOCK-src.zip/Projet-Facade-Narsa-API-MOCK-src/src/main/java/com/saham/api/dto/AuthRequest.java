package com.saham.api.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;

/**
 * Requête d'authentification OAuth.
 *
 * <p>Ce DTO transporte les identifiants nécessaires
 * pour l'authentification auprès du service OAuth.
 *
 * <p><b>Important :</b> Les noms des champs {@code UserName}
 * et {@code Password} sont volontairement conservés
 * tels quels afin de respecter le contrat JSON existant
 * (legacy / partenaire).
 */
@Schema(
    name = "AuthRequest",
    description = "Requête d'authentification OAuth (UserName / Password)"
)
public record AuthRequest(

    @Schema(
        description = "Nom d'utilisateur OAuth",
        example = "narsa-client-user"
    )
    @NotBlank(message = "UserName est obligatoire")
    String UserName,

    @Schema(
        description = "Mot de passe OAuth",
        example = "********"
    )
    @NotBlank(message = "Password est obligatoire")
    String Password

) {}
