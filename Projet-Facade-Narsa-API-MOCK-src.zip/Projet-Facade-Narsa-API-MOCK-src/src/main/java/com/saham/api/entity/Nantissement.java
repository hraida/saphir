package com.saham.api.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "NANTISSEMENT",
    indexes = {
        @Index(name="IDX_NANT_CHASSIS", columnList = "numChassis")
    },
    uniqueConstraints = {
        @UniqueConstraint(name="UK_NANT_TRIPLET", columnNames = {"codeSF","numContrat","numChassis"})
    }
)
public class Nantissement {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(nullable = false) private String codeSF;
  @Column(nullable = false) private String numContrat;
  @Column(nullable = false) private String numChassis;

  private Integer numWW;
  private Integer immatVeh1;
  private String immatVeh2;
  private Integer immatVeh3;

  @Column(nullable = false) private String typeVehicule;
  @Column(nullable = false) private String dateNantissement;

  @Column(nullable = false) private boolean mainLevee = false;

  public Long getId() { return id; }
  public String getCodeSF() { return codeSF; }
  public void setCodeSF(String codeSF) { this.codeSF = codeSF; }
  public String getNumContrat() { return numContrat; }
  public void setNumContrat(String numContrat) { this.numContrat = numContrat; }
  public String getNumChassis() { return numChassis; }
  public void setNumChassis(String numChassis) { this.numChassis = numChassis; }
  public Integer getNumWW() { return numWW; }
  public void setNumWW(Integer numWW) { this.numWW = numWW; }
  public Integer getImmatVeh1() { return immatVeh1; }
  public void setImmatVeh1(Integer immatVeh1) { this.immatVeh1 = immatVeh1; }
  public String getImmatVeh2() { return immatVeh2; }
  public void setImmatVeh2(String immatVeh2) { this.immatVeh2 = immatVeh2; }
  public Integer getImmatVeh3() { return immatVeh3; }
  public void setImmatVeh3(Integer immatVeh3) { this.immatVeh3 = immatVeh3; }
  public String getTypeVehicule() { return typeVehicule; }
  public void setTypeVehicule(String typeVehicule) { this.typeVehicule = typeVehicule; }
  public String getDateNantissement() { return dateNantissement; }
  public void setDateNantissement(String dateNantissement) { this.dateNantissement = dateNantissement; }
  public boolean isMainLevee() { return mainLevee; }
  public void setMainLevee(boolean mainLevee) { this.mainLevee = mainLevee; }
}
