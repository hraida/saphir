package com.saham.api.service;

import com.saham.api.exception.NarsaBusinessException;
import com.saham.api.store.TokenStore;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.Map;
import java.util.UUID;

@Service
public class OauthTokenService {

  private final TokenStore tokenStore;
  private final Clock clock;

  @Value("${mock.apigw.clientId}") private String clientId;
  @Value("${mock.apigw.clientSecret}") private String clientSecret;
  @Value("${mock.apigw.scope}") private String scopeExpected;
  @Value("${mock.apigw.oauthTtlMinutes:30}") private long ttlMin;

  public OauthTokenService(TokenStore tokenStore, Clock clock) {
    this.tokenStore = tokenStore;
    this.clock = clock;
  }

  public Map<String, Object> issue(String authorization, String grantType, String scope) {
    if (authorization == null || !authorization.startsWith("Basic ")) {
      throw new NarsaBusinessException(null, "D400", HttpStatus.BAD_REQUEST, "Missing Basic Authorization");
    }
    String decoded = new String(Base64.getDecoder().decode(authorization.substring(6)));
    String expected = clientId + ":" + clientSecret;
    if (!expected.equals(decoded)) {
      throw new NarsaBusinessException(null, "D400", HttpStatus.BAD_REQUEST, "Invalid client credentials");
    }
    if (!"client_credentials".equals(grantType) || !scopeExpected.equals(scope)) {
      throw new NarsaBusinessException(null, "D400", HttpStatus.BAD_REQUEST, "Invalid grant_type or scope");
    }

    String token = "oauth_" + UUID.randomUUID();
    Instant exp = Instant.now(clock).plus(ttlMin, ChronoUnit.MINUTES);
    tokenStore.putOauth(token, exp);

    return Map.of("access_token", token, "token_type", "bearer", "expires_in", ttlMin * 60);
  }
}
