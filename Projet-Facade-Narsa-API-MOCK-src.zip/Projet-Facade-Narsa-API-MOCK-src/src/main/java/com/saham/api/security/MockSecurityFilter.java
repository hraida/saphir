package com.saham.api.security;

import com.saham.api.store.TokenStore;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.Clock;
import java.time.Instant;

@Component
public class MockSecurityFilter implements Filter {

  private final TokenStore tokenStore;
  private final Clock clock;

  public MockSecurityFilter(TokenStore tokenStore, Clock clock) {
    this.tokenStore = tokenStore;
    this.clock = clock;
  }

  @Override
  public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
    HttpServletRequest r = (HttpServletRequest) req;
    HttpServletResponse w = (HttpServletResponse) res;

    String path = r.getRequestURI();
    if (path.equals("/token") || path.startsWith("/swagger") || path.startsWith("/v3/api-docs") || path.startsWith("/h2-console")) {
      chain.doFilter(req, res);
      return;
    }

    String auth = r.getHeader("Authorization");
    if (auth == null || !auth.startsWith("Bearer ")) {
      w.setStatus(401);
      return;
    }

    String oauth = auth.substring(7);
    Instant now = Instant.now(clock);
    if (!tokenStore.isOauthValid(oauth, now)) {
      w.setStatus(401);
      return;
    }

    if (path.startsWith("/narsa-financing-services/v1/nantissements")) {
      String xToken = r.getHeader("X-Token");
      if (xToken == null || !tokenStore.isXTokenValid(xToken, now)) {
        w.setStatus(401);
        return;
      }
    }

    chain.doFilter(req, res);
  }
}
