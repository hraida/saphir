package com.saham.api.config;

import com.saham.api.store.TokenStore;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Clock;

@Configuration
public class AppBeans {
  @Bean public TokenStore tokenStore() { return new TokenStore(); }
  @Bean public Clock clock() { return Clock.systemDefaultZone(); }
}
