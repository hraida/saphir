package com.saham.api.dto;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Réponse d'authentification OAuth.
 *
 * <p>Retourne le résultat de l'appel d'authentification :
 * <ul>
 *   <li>{@code Statut} : indique si l'authentification est réussie</li>
 *   <li>{@code Message} : message fonctionnel (succès/erreur)</li>
 *   <li>{@code Token} : informations du token (présent si succès)</li>
 * </ul>
 *
 * <p><b>Important :</b> Les noms des champs sont conservés tels quels
 * (Statut, Message, Token...) afin de respecter le contrat JSON existant.
 */
@Schema(
    name = "AuthResponse",
    description = "Réponse d'authentification OAuth (contrat JSON legacy conservé)"
)
public record AuthResponse(

    @Schema(
        description = "Statut de l'authentification (true si succès, false sinon)",
        example = "true"
    )
    boolean Statut,

    @Schema(
        description = "Message fonctionnel associé au résultat",
        example = "Authentification réussie"
    )
    String Message,

    @Schema(
        description = "Détails du token OAuth (null si échec d'authentification)",
        nullable = true
    )
    Token Token

) {

  /**
   * Détails du token OAuth.
   *
   * <p>Contient les tokens retournés par le serveur OAuth
   * et la date/heure d'expiration.
   */
  @Schema(
      name = "AuthToken",
      description = "Informations du token OAuth (IdToken, AccessToken, DateExpiration)"
  )
  public record Token(

      @Schema(
          description = "ID Token (JWT) - informations d'identité (selon le provider OAuth)",
          example = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
      )
      String IdToken,

      @Schema(
          description = "Access Token (JWT) - utilisé pour appeler les APIs protégées",
          example = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
      )
      String AccessToken,

      @Schema(
          description = "Date/heure d'expiration du token (format ISO recommandé)",
          example = "2026-01-05T12:30:00"
      )
      String DateExpiration

  ) {}
}
