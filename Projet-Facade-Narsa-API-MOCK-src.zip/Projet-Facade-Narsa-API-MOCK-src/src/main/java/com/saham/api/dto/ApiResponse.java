package com.saham.api.dto;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Réponse API générique.
 *
 * <p>Ce DTO standardise les réponses de l'API pour les traitements
 * ne retournant pas de données métier complexes (création, mainlevée, erreur).
 *
 * <p>Il est utilisé pour assurer une réponse homogène,
 * traçable et facilement interprétable par les systèmes appelants.
 */
@Schema(
    name = "ApiResponse",
    description = "Réponse générique de l'API (statut et message métier)"
)
public record ApiResponse(

    @Schema(
        description = "Identifiant unique de la requête (corrélation)",
        example = "9f2b2c20-7b24-4b9f-9d55-4ce0b62c7a42"
    )
    String idRequete,

    @Schema(
        description = "Code retour du traitement",
        example = "00"
    )
    String codeRetour,

    @Schema(
        description = "Message fonctionnel associé au code retour",
        example = "Traitement effectué avec succès"
    )
    String messageRetour

) {}
