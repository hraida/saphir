package com.saham.api.store;

import java.time.Instant;
import java.util.concurrent.ConcurrentHashMap;

public class TokenStore {
  private final ConcurrentHashMap<String, Instant> oauthTokens = new ConcurrentHashMap<>();
  private final ConcurrentHashMap<String, Instant> xTokens = new ConcurrentHashMap<>();

  public void putOauth(String token, Instant exp) { oauthTokens.put(token, exp); }
  public boolean isOauthValid(String token, Instant now) {
    Instant exp = oauthTokens.get(token);
    return exp != null && exp.isAfter(now);
  }

  public void putXToken(String token, Instant exp) { xTokens.put(token, exp); }
  public boolean isXTokenValid(String token, Instant now) {
    Instant exp = xTokens.get(token);
    return exp != null && exp.isAfter(now);
  }
}
