package com.saham.api.exception;

import com.saham.api.dto.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

  @ExceptionHandler(NarsaBusinessException.class)
  public ResponseEntity<ApiResponse> handleBusiness(NarsaBusinessException ex) {
    String http = String.valueOf(ex.getHttpStatus().value());
    String msg = ex.getCodeMetier() + " : " + ex.getMessage();
    return ResponseEntity.status(ex.getHttpStatus()).body(new ApiResponse(ex.getIdRequete(), http, msg));
  }

  @ExceptionHandler(Exception.class)
  public ResponseEntity<ApiResponse> handleAny(Exception ex) {
    return ResponseEntity.status(500).body(new ApiResponse(null, "500", "D500 : Erreur interne"));
  }
}
