package com.saham.api.repo;

import com.saham.api.entity.Nantissement;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface NantissementRepository extends JpaRepository<Nantissement, Long> {
  Optional<Nantissement> findFirstByNumChassis(String numChassis);
  Optional<Nantissement> findByCodeSFAndNumContratAndNumChassis(String codeSF, String numContrat, String numChassis);
}
