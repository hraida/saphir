package com.saham.api.controller;

import com.saham.api.dto.*;
import com.saham.api.service.NarsaAuthService;
import com.saham.api.service.NantissementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * API NARSA Financing Services.
 *
 * <p>
 * Ce contrôleur expose les endpoints REST pour :
 * <ul>
 * <li>Authentification OAuth</li>
 * <li>Création de nantissement</li>
 * <li>Consultation de nantissement</li>
 * <li>Mainlevée (lever un nantissement)</li>
 * </ul>
 *
 * <p>
 * <b>Traçabilité :</b> le header {@code X-Request-ID} sert d'identifiant de
 * corrélation (logs, audit).
 *
 * <p>
 * <b>Gestion des erreurs :</b> en cas d’erreur (400/401/404/409/500), la
 * réponse est standardisée via {@link ApiResponse} (idRequete, codeRetour,
 * messageRetour).
 */
@RestController
@RequestMapping(value = "/narsa-financing-services/v1", produces = MediaType.APPLICATION_JSON_VALUE)
@Tag(name = "NARSA Financing Services", description = "API d’authentification et de gestion des Nantissements / Mainlevées (NARSA).")
public class NarsaFinancingController {

	private final NarsaAuthService authService;
	private final NantissementService nantService;

	public NarsaFinancingController(NarsaAuthService authService, NantissementService nantService) {
		this.authService = authService;
		this.nantService = nantService;
	}

	@Operation(summary = "Authentification OAuth NARSA", description = "Permet l’authentification et retourne les informations de token OAuth.")
	@io.swagger.v3.oas.annotations.responses.ApiResponses(value = {
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Authentification réussie", content = @Content(schema = @Schema(implementation = AuthResponse.class))),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400", description = "Requête invalide", content = @Content(schema = @Schema(implementation = ApiResponse.class))),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "401", description = "Non autorisé (credentials invalides)", content = @Content(schema = @Schema(implementation = ApiResponse.class))),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "500", description = "Erreur interne", content = @Content(schema = @Schema(implementation = ApiResponse.class))) })
	@PostMapping(value = "/authentification", consumes = MediaType.APPLICATION_JSON_VALUE)
	public AuthResponse authenticate(
			@Parameter(description = "Header Authorization (Bearer ...)", required = true, example = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...") @RequestHeader("Authorization") String bearerOauth,

			@Parameter(description = "Identifiant du client appelant", required = true, example = "SAHAM-APP-001") @RequestHeader("X-Client-ID") String clientId,

			@Parameter(description = "Identifiant unique de requête (corrélation / audit)", required = true, example = "9f2b2c20-7b24-4b9f-9d55-4ce0b62c7a42") @RequestHeader("X-Request-ID") String requestId,

			@Parameter(description = "Nom de l’application appelante", required = true, example = "PORTAIL-FINANCEMENT") @RequestHeader("X-Request-Application-Name") String appName,

			@io.swagger.v3.oas.annotations.parameters.RequestBody(required = true, description = "Paramètres d’authentification", content = @Content(schema = @Schema(implementation = AuthRequest.class))) @RequestBody AuthRequest body) {
		return authService.authenticate(body);
	}

	@Operation(summary = "Créer un nantissement", description = "Déclare un nantissement pour un véhicule financé.")
	@io.swagger.v3.oas.annotations.responses.ApiResponses(value = {
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "201", description = "Nantissement créé", content = @Content(schema = @Schema(implementation = ApiResponse.class))),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400", description = "Requête invalide", content = @Content(schema = @Schema(implementation = ApiResponse.class))),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "409", description = "Conflit métier (déjà existant / règle bloquante)", content = @Content(schema = @Schema(implementation = ApiResponse.class))),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "500", description = "Erreur interne", content = @Content(schema = @Schema(implementation = ApiResponse.class))) })
	@PostMapping(value = "/nantissements/creer", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse> creer(
			@Parameter(description = "Identifiant unique de requête (corrélation / audit)", required = true, example = "9f2b2c20-7b24-4b9f-9d55-4ce0b62c7a42") @RequestHeader("X-Request-ID") String requestId,

			@io.swagger.v3.oas.annotations.parameters.RequestBody(required = true, description = "Données de création du nantissement", content = @Content(schema = @Schema(implementation = NantissementCreateRequest.class))) @RequestBody NantissementCreateRequest body) {
		return ResponseEntity.status(201).body(nantService.creer(body));
	}

	@Operation(summary = "Consulter un nantissement", description = "Retourne l’état du nantissement et les informations associées au véhicule.")
	@io.swagger.v3.oas.annotations.responses.ApiResponses(value = {
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200", description = "Consultation réussie", content = @Content(schema = @Schema(implementation = ConsultResponse.class))),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400", description = "Requête invalide", content = @Content(schema = @Schema(implementation = ApiResponse.class))),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Nantissement non trouvé (selon règle métier)", content = @Content(schema = @Schema(implementation = ApiResponse.class))),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "500", description = "Erreur interne", content = @Content(schema = @Schema(implementation = ApiResponse.class))) })
	@PostMapping(value = "/nantissements/consulter", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ConsultResponse> consulter(
			@Parameter(description = "Identifiant unique de requête (corrélation / audit)", required = true, example = "9f2b2c20-7b24-4b9f-9d55-4ce0b62c7a42") @RequestHeader("X-Request-ID") String requestId,

			@io.swagger.v3.oas.annotations.parameters.RequestBody(required = true, description = "Critères de consultation du nantissement", content = @Content(schema = @Schema(implementation = NantissementConsultRequest.class))) @RequestBody NantissementConsultRequest body) {
		return ResponseEntity.ok(nantService.consulter(body));
	}

	@Operation(summary = "Lever un nantissement (mainlevée)", description = "Effectue la mainlevée d’un nantissement existant.")
	@io.swagger.v3.oas.annotations.responses.ApiResponses(value = {
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "201", description = "Mainlevée effectuée", content = @Content(schema = @Schema(implementation = ApiResponse.class))),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400", description = "Requête invalide", content = @Content(schema = @Schema(implementation = ApiResponse.class))),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Nantissement introuvable / non éligible", content = @Content(schema = @Schema(implementation = ApiResponse.class))),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "409", description = "Conflit métier (déjà levé, statut incompatible...)", content = @Content(schema = @Schema(implementation = ApiResponse.class))),
			@io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "500", description = "Erreur interne", content = @Content(schema = @Schema(implementation = ApiResponse.class))) })
	@PostMapping(value = "/nantissements/lever", consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ApiResponse> lever(
			@Parameter(description = "Identifiant unique de requête (corrélation / audit)", required = true, example = "9f2b2c20-7b24-4b9f-9d55-4ce0b62c7a42") @RequestHeader("X-Request-ID") String requestId,

			@io.swagger.v3.oas.annotations.parameters.RequestBody(required = true, description = "Données de mainlevée du nantissement", content = @Content(schema = @Schema(implementation = NantissementLeverRequest.class))) @RequestBody NantissementLeverRequest body) {
		return ResponseEntity.status(201).body(nantService.lever(body));
	}
}
