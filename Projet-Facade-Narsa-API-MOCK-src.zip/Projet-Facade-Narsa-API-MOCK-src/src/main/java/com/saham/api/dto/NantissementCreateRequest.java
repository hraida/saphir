package com.saham.api.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

/**
 * Requête de création d'un nantissement NARSA.
 *
 * <p>Ce DTO transporte l'ensemble des informations nécessaires à la
 * déclaration d'un véhicule financé comme "nantis" auprès de NARSA.
 *
 * <p>Il est utilisé dans le cadre d'une première déclaration de nantissement
 * suite à l'octroi d'un crédit automobile.
 */
@Schema(
    name = "NantissementCreateRequest",
    description = "Données nécessaires à la création d'un nantissement auprès de NARSA"
)
public class NantissementCreateRequest {

  /**
   * Identifiant unique de la requête.
   *
   * <p>Utilisé pour la traçabilité, la corrélation des logs
   * et le suivi des échanges avec NARSA.
   */
  @Schema(
      description = "Identifiant unique de la requête (corrélation)",
      example = "b7a1e8c3-9f4a-4c6b-9f3e-1cdd2a7b91aa"
  )
  @NotBlank(message = "idRequete est obligatoire")
  public String idRequete;

  /**
   * Code de la Société de Financement (SF).
   *
   * <p>Identifie l'organisme financier déclarant le nantissement.
   */
  @Schema(
      description = "Code de la société de financement",
      example = "SAHAM"
  )
  @NotBlank(message = "codeSF est obligatoire")
  public String codeSF;

  /**
   * Numéro du contrat de financement.
   *
   * <p>Référence interne du contrat de crédit associé au véhicule.
   */
  @Schema(
      description = "Numéro du contrat de financement",
      example = "CNTR-2024-001245"
  )
  @NotBlank(message = "numContrat est obligatoire")
  public String numContrat;

  /**
   * Identifiant du type de nantissement.
   *
   * <p>Valeur définie selon le référentiel NARSA / interne.
   */
  @Schema(
      description = "Identifiant du type de nantissement",
      example = "1"
  )
  @NotBlank(message = "idType est obligatoire")
  public String idType;

  /**
   * Identifiant du bénéficiaire du nantissement.
   *
   * <p>Correspond généralement à la société de financement
   * ou à l'organisme bénéficiaire.
   */
  @Schema(
      description = "Identifiant du bénéficiaire",
      example = "SAHAM-FINANCE"
  )
  @NotBlank(message = "idBeneficiaire est obligatoire")
  public String idBeneficiaire;

  /**
   * Ville d'immatriculation (RC).
   *
   * <p>Code numérique de la ville tel que défini par le référentiel NARSA.
   */
  @Schema(
      description = "Code de la ville d'immatriculation (RC)",
      example = "1"
  )
  @NotNull(message = "villeRC est obligatoire")
  @JsonAlias({"villeRC", "villeRc"})
  public Integer villeRC;

  /**
   * Intitulé du bénéficiaire du nantissement.
   *
   * <p>Libellé affichable du bénéficiaire (raison sociale).
   */
  @Schema(
      description = "Intitulé du bénéficiaire",
      example = "SAHAM FINANCE"
  )
  @NotBlank(message = "intituleBeneficiaire est obligatoire")
  @JsonAlias({"intituleBeneficaire", "intituleBeneficiaire"})
  public String intituleBeneficiaire;

  /**
   * Numéro WW (immatriculation provisoire).
   *
   * <p>Renseigné uniquement si le véhicule dispose
   * d'une immatriculation provisoire.
   */
  @Schema(
      description = "Numéro WW (immatriculation provisoire)",
      example = "12345"
  )
  public Integer numWW;

  /**
   * Première partie de l'immatriculation définitive.
   */
  @Schema(
      description = "Partie 1 de l'immatriculation du véhicule",
      example = "1234"
  )
  public Integer immatVeh1;

  /**
   * Deuxième partie (lettres) de l'immatriculation.
   */
  @Schema(
      description = "Partie 2 (lettres) de l'immatriculation",
      example = "A"
  )
  public String immatVeh2;

  /**
   * Troisième partie de l'immatriculation.
   */
  @Schema(
      description = "Partie 3 de l'immatriculation du véhicule",
      example = "56"
  )
  public Integer immatVeh3;

  /**
   * Type du véhicule financé.
   *
   * <p>Exemples : VP, VU, MOTO.
   */
  @Schema(
      description = "Type du véhicule (VP, VU, MOTO, ...)",
      example = "VP"
  )
  @NotBlank(message = "typeVehicule est obligatoire")
  public String typeVehicule;

  /**
   * Numéro de châssis (VIN).
   *
   * <p>Identifiant unique international du véhicule.
   */
  @Schema(
      description = "Numéro de châssis (VIN)",
      example = "VF1RFA00412345678"
  )
  @NotBlank(message = "numChassis est obligatoire")
  public String numChassis;

  /**
   * Date de déclaration du nantissement.
   *
   * <p>Format attendu : {@code yyyy-MM-dd}.
   */
  @Schema(
      description = "Date de déclaration du nantissement (format yyyy-MM-dd)",
      example = "2024-06-01"
  )
  @Pattern(
      regexp = "^\\d{4}-\\d{2}-\\d{2}$",
      message = "dateNantissement doit respecter le format yyyy-MM-dd"
  )
  @NotBlank(message = "dateNantissement est obligatoire")
  public String dateNantissement;
}
