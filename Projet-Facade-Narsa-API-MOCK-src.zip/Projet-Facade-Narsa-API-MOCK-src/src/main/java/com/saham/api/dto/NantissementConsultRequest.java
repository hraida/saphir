package com.saham.api.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

/**
 * Requête de consultation d'un nantissement NARSA.
 *
 * <p>Ce DTO permet de transmettre les critères nécessaires pour consulter
 * l'état d'un nantissement lié à un véhicule financé (existant, levé, inexistant).
 *
 * <p>L'identifiant {@code idRequete} est utilisé pour la traçabilité,
 * la corrélation des appels et le suivi des échanges avec NARSA.
 */
@Schema(
    name = "NantissementConsultRequest",
    description = "Critères de consultation d'un nantissement auprès de NARSA"
)
public class NantissementConsultRequest {

  /**
   * Identifiant unique de la requête.
   *
   * <p>Généré par le système appelant afin d'assurer :
   * <ul>
   *   <li>la traçabilité des échanges</li>
   *   <li>la corrélation des logs</li>
   *   <li>le suivi fonctionnel et technique</li>
   * </ul>
   */
  @Schema(
      description = "Identifiant unique de la requête (corrélation)",
      example = "9f2b2c20-7b24-4b9f-9d55-4ce0b62c7a42"
  )
  @NotBlank(message = "idRequete est obligatoire")
  public String idRequete;

  /**
   * Code de la Société de Financement (SF).
   *
   * <p>Identifie l'organisme financier déclarant ou consultant le nantissement.
   */
  @Schema(
      description = "Code de la société de financement",
      example = "SAHAM"
  )
  @NotBlank(message = "codeSF est obligatoire")
  public String codeSF;

  /**
   * Numéro de contrat de financement.
   *
   * <p>Référence interne du contrat de crédit associé au véhicule.
   */
  @Schema(
      description = "Numéro du contrat de financement",
      example = "CNTR-2024-000987"
  )
  @NotBlank(message = "numContrat est obligatoire")
  public String numContrat;

  /**
   * Type du véhicule financé.
   *
   * <p>Valeurs usuelles :
   * <ul>
   *   <li>VP : Véhicule Particulier</li>
   *   <li>VU : Véhicule Utilitaire</li>
   *   <li>MOTO : Motocycle</li>
   * </ul>
   */
  @Schema(
      description = "Type du véhicule (VP, VU, MOTO, ...)",
      example = "VP"
  )
  @NotBlank(message = "typeVehicule est obligatoire")
  public String typeVehicule;

  /**
   * Numéro de châssis du véhicule.
   *
   * <p>Identifiant unique international (VIN) du véhicule.
   */
  @Schema(
      description = "Numéro de châssis (VIN)",
      example = "VF1RFA00412345678"
  )
  @NotBlank(message = "numChassis est obligatoire")
  public String numChassis;

  /**
   * Date de déclaration du nantissement.
   *
   * <p>Format attendu : {@code yyyy-MM-dd}.
   * <p>Ce champ peut être utilisé pour affiner la recherche
   * lorsqu'un même véhicule a plusieurs historiques.
   */
  @Schema(
      description = "Date de déclaration du nantissement (format yyyy-MM-dd)",
      example = "2024-05-12"
  )
  @Pattern(
      regexp = "^\\d{4}-\\d{2}-\\d{2}$",
      message = "dateNantissement doit respecter le format yyyy-MM-dd"
  )
  public String dateNantissement;
}
