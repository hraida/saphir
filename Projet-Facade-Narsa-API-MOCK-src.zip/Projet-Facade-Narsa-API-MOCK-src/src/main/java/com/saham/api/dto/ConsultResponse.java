package com.saham.api.dto;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Réponse de consultation d'un nantissement NARSA.
 *
 * <p>Ce DTO représente le résultat retourné suite à une
 * demande de consultation de nantissement.
 *
 * <p>Il permet de connaître l'état du véhicule, les informations
 * d'immatriculation ainsi que les métadonnées de traitement.
 */
@Schema(
    name = "ConsultResponse",
    description = "Résultat de la consultation d'un nantissement auprès de NARSA"
)
public record ConsultResponse(

    @Schema(
        description = "Identifiant unique de la requête (corrélation)",
        example = "9f2b2c20-7b24-4b9f-9d55-4ce0b62c7a42"
    )
    String idRequete,

    @Schema(
        description = "Code retour du traitement",
        example = "00"
    )
    String codeRetour,

    @Schema(
        description = "Message fonctionnel associé au code retour",
        example = "Nantissement trouvé"
    )
    String messageRetour,

    @Schema(
        description = "Numéro du contrat de financement",
        example = "CNTR-2024-001245"
    )
    String numContrat,

    @Schema(
        description = "Numéro WW (immatriculation provisoire), si existant",
        example = "12345",
        nullable = true
    )
    Integer numWW,

    @Schema(
        description = "Première partie de l'immatriculation définitive",
        example = "1234",
        nullable = true
    )
    Integer immatVeh1,

    @Schema(
        description = "Deuxième partie (lettres) de l'immatriculation",
        example = "A",
        nullable = true
    )
    String immatVeh2,

    @Schema(
        description = "Troisième partie de l'immatriculation définitive",
        example = "56",
        nullable = true
    )
    Integer immatVeh3,

    @Schema(
        description = "Type du véhicule (VP, VU, MOTO, ...)",
        example = "VP"
    )
    String typeVehicule,

    @Schema(
        description = "Numéro de châssis (VIN) du véhicule",
        example = "VF1RFA00412345678"
    )
    String numChassis,

    @Schema(
        description = "Date de déclaration du nantissement (format yyyy-MM-dd)",
        example = "2024-05-12"
    )
    String dateNantissement

) {}
