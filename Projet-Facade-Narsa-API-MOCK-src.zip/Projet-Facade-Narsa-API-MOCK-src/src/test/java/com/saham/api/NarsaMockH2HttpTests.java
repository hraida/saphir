package com.saham.api;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.UUID;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class NarsaMockH2HttpTests {

  private final MockMvc mvc;

  NarsaMockH2HttpTests(MockMvc mvc) { this.mvc = mvc; }

  @Value("${mock.apigw.clientId}") String clientId;
  @Value("${mock.apigw.clientSecret}") String clientSecret;
  @Value("${mock.apigw.scope}") String scope;
  @Value("${mock.narsa.secret}") String narsaSecret;

  String oauthToken;
  String xToken;

  @BeforeEach
  void initTokens() throws Exception {
    oauthToken = getOauthToken();
    xToken = getXToken(oauthToken);
  }

  String getOauthToken() throws Exception {
    String basic = Base64.getEncoder().encodeToString((clientId + ":" + clientSecret).getBytes(StandardCharsets.UTF_8));
    MvcResult res = mvc.perform(post("/token")
            .contentType(MediaType.APPLICATION_FORM_URLENCODED)
            .header("Authorization", "Basic " + basic)
            .param("grant_type", "client_credentials")
            .param("scope", scope))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.access_token").exists())
        .andReturn();

    String body = res.getResponse().getContentAsString();
    return body.split("\"access_token\"\s*:\s*\"")[1].split("\"")[0];
  }

  String getXToken(String oauth) throws Exception {
    String today = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);
    String hash = HashUtil.sha256Hex("NARSA-APSF" + today + narsaSecret);

    MvcResult res = mvc.perform(post("/narsa-financing-services/v1/authentification")
            .contentType(MediaType.APPLICATION_JSON)
            .header("Authorization", "Bearer " + oauth)
            .header("X-Client-ID", "ADD")
            .header("X-Request-ID", UUID.randomUUID().toString())
            .header("X-Request-Application-Name", "ADD")
            .content("{\"UserName\":\"USER_EQDOM\",\"Password\":\"" + hash + "\"}"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.Token.AccessToken").exists())
        .andReturn();

    String body = res.getResponse().getContentAsString();
    return body.split("\"AccessToken\"\s*:\s*\"")[1].split("\"")[0];
  }

  String guid() { return UUID.randomUUID().toString(); }

  @Test
  void consultation_should_echo_idRequete() throws Exception {
    String chassis = "H2CHASSIS000000001";
    String idCreate = guid();

    String createJson =
        "{\"idRequete\":\"" + idCreate + "\",\"codeSF\":\"001645879912458\",\"numContrat\":\"C1205XF12\"," +
        "\"idType\":\"CIN\",\"idBeneficiaire\":\"AB123\",\"intituleBeneficiaire\":\"CLIENT X\"," +
        "\"numWW\":152063,\"typeVehicule\":\"N\",\"numChassis\":\"" + chassis + "\",\"dateNantissement\":\"12/12/2020 15:30:00\"}";

    mvc.perform(post("/narsa-financing-services/v1/nantissements/creer")
            .contentType(MediaType.APPLICATION_JSON)
            .header("Authorization", "Bearer " + oauthToken)
            .header("X-Token", xToken)
            .header("X-Request-ID", idCreate)
            .content(createJson))
        .andExpect(status().isCreated())
        .andExpect(jsonPath("$.idRequete").value(idCreate))
        .andExpect(jsonPath("$.codeRetour").value("201"));

    String idConsult = guid();
    String consultJson =
        "{\"idRequete\":\"" + idConsult + "\",\"codeSF\":\"001645879912458\",\"numContrat\":\"C1205XF12\"," +
        "\"typeVehicule\":\"N\",\"numChassis\":\"" + chassis + "\",\"dateNantissement\":\"12/12/2020 15:30:00\"}";

    mvc.perform(post("/narsa-financing-services/v1/nantissements/consulter")
            .contentType(MediaType.APPLICATION_JSON)
            .header("Authorization", "Bearer " + oauthToken)
            .header("X-Token", xToken)
            .header("X-Request-ID", idConsult)
            .content(consultJson))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.idRequete").value(idConsult))
        .andExpect(jsonPath("$.codeRetour").value("200"));
  }

  @Test
  void mainlevee_should_echo_idRequete() throws Exception {
    String chassis = "H2CHASSIS000000002";
    String idCreate = guid();

    String createJson =
        "{\"idRequete\":\"" + idCreate + "\",\"codeSF\":\"001645879912458\",\"numContrat\":\"C1205XF12\"," +
        "\"idType\":\"CIN\",\"idBeneficiaire\":\"AB123\",\"intituleBeneficiaire\":\"CLIENT X\"," +
        "\"numWW\":152063,\"typeVehicule\":\"N\",\"numChassis\":\"" + chassis + "\",\"dateNantissement\":\"12/12/2020 15:30:00\"}";

    mvc.perform(post("/narsa-financing-services/v1/nantissements/creer")
            .contentType(MediaType.APPLICATION_JSON)
            .header("Authorization", "Bearer " + oauthToken)
            .header("X-Token", xToken)
            .header("X-Request-ID", idCreate)
            .content(createJson))
        .andExpect(status().isCreated());

    String idLever = guid();
    String leverJson =
        "{\"idRequete\":\"" + idLever + "\",\"codeSF\":\"001645879912458\",\"numContrat\":\"C1205XF12\"," +
        "\"numChassis\":\"" + chassis + "\",\"dateMainlevee\":\"12/12/2020 15:30:00\"}";

    mvc.perform(post("/narsa-financing-services/v1/nantissements/lever")
            .contentType(MediaType.APPLICATION_JSON)
            .header("Authorization", "Bearer " + oauthToken)
            .header("X-Token", xToken)
            .header("X-Request-ID", idLever)
            .content(leverJson))
        .andExpect(status().isCreated())
        .andExpect(jsonPath("$.idRequete").value(idLever))
        .andExpect(jsonPath("$.codeRetour").value("201"));
  }

  @Test
  void consultation_error_should_echo_idRequete_too() throws Exception {
    String idConsult = guid();
    String consultJson =
        "{\"idRequete\":\"" + idConsult + "\",\"codeSF\":\"001645879912458\",\"numContrat\":\"C1205XF12\"," +
        "\"typeVehicule\":\"N\",\"numChassis\":\"UNKNOWN\",\"dateNantissement\":\"12/12/2020 15:30:00\"}";

    mvc.perform(post("/narsa-financing-services/v1/nantissements/consulter")
            .contentType(MediaType.APPLICATION_JSON)
            .header("Authorization", "Bearer " + oauthToken)
            .header("X-Token", xToken)
            .header("X-Request-ID", idConsult)
            .content(consultJson))
        .andExpect(status().isNotAcceptable())
        .andExpect(jsonPath("$.idRequete").value(idConsult))
        .andExpect(jsonPath("$.codeRetour").value("406"));
  }
}
